import 'dart:ffi';
import 'dart:io';
import '../model/FaqsModel/FaqsResponse.dart';
import '../model/TermsAndConditionsModel/TermsAndConditionsResponse.dart';
import '../model/aboutAsModel/AboutAsResponse.dart';
import '../model/addressModel/addAddressModel/AddAddressResponse.dart';
import '../model/addressModel/addressListModel/AddressListResponse.dart';
import '../model/addressModel/deleteModel/DeleteResponse.dart';
import '../model/addressModel/editAddressModel/EditAddressResponse.dart';
import '../model/auth/createUserModel/CompleteUserInfoResponse.dart';
import '../model/auth/introModel/IntroResponse.dart';
import '../model/auth/loginModel/LoginResponse.dart';
import '../model/auth/verifyModel/VerifyCodeResponse.dart';
import '../model/auth/verifyModel/resendModel/ResendCodeResponse.dart';
import '../model/basketModel/BasketListResponse.dart';
import '../model/createOrderBasketModel/CreateOrderBasketResponse.dart';
import '../model/homeModel/HomeResponse.dart';
import '../model/preferencesModel/PreferencesResponse.dart';
import '../model/socialModel/SocialResponse.dart';
import '../web_service/WebServices.dart';

class Repo {
  WebService webService;
  Repo(this.webService);

  Future<IntroResponse> getIntro()async{
    final intro=await webService.getIntro();
    return intro;
  }

  Future<LoginResponse> login(String phone,String code)async{
    final login=await webService.login(phone,code);
    return login;
  }

  Future<VerifyCodeResponse> verifyCode(String code)async{
    final verify=await webService.verifyCode(code);
    return verify;
  }

  Future<ResendCodeResponse> resendCode()async{
    final resend=await webService.resendCode();
    return resend;
  }

  Future<CompleteUserInfoResponse> completeUserInfo(String name,
      String streetName,
      String type,String lat,String lng,
      String email,String phone)async{
    final completeUserInfo=await webService.completeUserInfo(name, streetName, type, lat, lng, email,phone);
    return completeUserInfo;
  }

  Future<CompleteUserInfoResponse> updateProfile(String name,String email,String mobile)async{
    final update=await webService.updateProfile(name, email, mobile);
    return update;
  }

  Future<FaqsResponse> faqs(String type)async{
    final faqs=await webService.faqs(type);
    return faqs;
  }

  Future<TermsAndConditionsResponse> termsAndCondition()async{
    final terms=await webService.termsAndCondition();
    return terms;
  }

  Future<AboutAsResponse> aboutUs()async{
    final about=await webService.aboutUs();
    return about;
  }

  Future<SocialResponse> getSocialLinks()async{
    final social=await webService.getSocialLinks();
    return social;
  }

  Future<AddressListResponse> getAddress()async{
    final address=await webService.getAddress();
    return address;
  }

  Future<DeleteResponse> deleteAddress(int id)async{
    final delete=await webService.deleteAddress(id);
    return delete;
  }

  Future<AddAddressResponse> addAddress(String address,String lat,String lng,String type)async{
    final Addaddress=await webService.addAddress(address, lat, lng, type);
    return Addaddress;
  }

  Future<EditAddressResponse> editAddress(String address,String lat,String lng,String type,int id)async{
    final Editaddress=await webService.editAddress(address, lat, lng, type,id);
    return Editaddress;
  }

  Future<BasketListResponse> getBaskets(String lat,String lng)async{
    final baskets=await webService.getBaskets(lat, lng);
    return baskets;
  }

  Future<PreferencesResponse> getPreferences(String lat,String lng)async{
    final preferences=await webService.getPreferences(lat, lng);
    return preferences;
  }

  Future<HomeResponse> getHomeData(String lat,String lng)async{
    final home=await webService.getHomeData(lat, lng);
    return home;
  }

  Future<CreateOrderBasketResponse> createOrderBasket(
      int addressId,
      int couponId,
      String type,
      String deliveryDate,
      String payment,
      String notes,
      String totalAfterDiscount,
      String discount,
      String total,
      String products)async{
    final orderBasket=await webService.createOrderBasket(addressId, couponId, type, deliveryDate, payment, notes, totalAfterDiscount, discount, total, products);
    return orderBasket;
  }

}