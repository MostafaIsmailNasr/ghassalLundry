import 'package:dio/dio.dart' as dio1;
import 'package:dio/dio.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http_parser/http_parser.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:path/path.dart';

import '../../conustant/di.dart';
import '../../conustant/my_colors.dart';
import '../../conustant/shared_preference_serv.dart';
import '../model/FaqsModel/FaqsResponse.dart';
import '../model/TermsAndConditionsModel/TermsAndConditionsResponse.dart';
import '../model/aboutAsModel/AboutAsResponse.dart';
import '../model/addressModel/addAddressModel/AddAddressResponse.dart';
import '../model/addressModel/addressListModel/AddressListResponse.dart';
import '../model/addressModel/deleteModel/DeleteResponse.dart';
import '../model/addressModel/editAddressModel/EditAddressResponse.dart';
import '../model/auth/createUserModel/CompleteUserInfoResponse.dart';
import '../model/auth/introModel/IntroResponse.dart';
import '../model/auth/loginModel/LoginResponse.dart';
import '../model/auth/verifyModel/VerifyCodeResponse.dart';
import '../model/auth/verifyModel/resendModel/ResendCodeResponse.dart';
import '../model/basketModel/BasketListResponse.dart';
import '../model/createOrderBasketModel/CreateOrderBasketResponse.dart';
import '../model/homeModel/HomeResponse.dart';
import '../model/preferencesModel/PreferencesResponse.dart';
import '../model/socialModel/SocialResponse.dart';


class WebService {
  late dio1.Dio dio;
  late dio1.BaseOptions options;
  var baseUrl = "https://ghassal.mtjrsahl-ksa.com/api";
  final SharedPreferencesService sharedPreferencesService =
  instance<SharedPreferencesService>();
  // var language;
  // var userToken;

  WebService() {
    options = dio1.BaseOptions(
      baseUrl: baseUrl,
      receiveDataWhenStatusError: true,
      connectTimeout: Duration(milliseconds: 70 * 1000),
      receiveTimeout: Duration(milliseconds: 70 * 1000),
    );
    dio = dio1.Dio(options);
  }

  void handleError(DioException e) {
    String message = '';

    if (e.error is SocketException) {
      message = 'No internet connection';
    }  else if (e.response != null) {
      if (e.response?.statusCode == 422) {
        dynamic responseData = e.response!.data['message'];

        if (responseData is List) {
          if (responseData.isNotEmpty) {
            message = responseData[0];
          }
        } else
        if (responseData is String) {
          message = responseData;
        } else {
          message = 'An error occurred';
        }
      } else {
        message = '${e.response}';
      }
    } else if (e.type == DioExceptionType.cancel) {
      message = 'Request was canceled';
    } else {
      message = 'An error occurred';
    }
    Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.TOP,
        timeInSecForIosWeb: 1,backgroundColor: MyColors.SupportiveChichi
    );
    print("jkjkjkjik"+message);
  }

  Future<IntroResponse> getIntro()async{
    try {
    var Url="/introduction_screens";
    print(Url);
    print(options.baseUrl+Url);
    dio1.Response response = await dio.get(Url, //data: params,
        options: dio1.Options(
          headers: {
            "Locale": sharedPreferencesService.getString("lang"),
          },
        )
    );
    print(response);
    return IntroResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return IntroResponse();
    }
  }

  Future<LoginResponse> login(String phone,String code)async{
    try {
      var LoginUrl="/login";
      print(LoginUrl);
      var params={
        'mobile': phone,
        'refer_code': code,
      };
      print(options.baseUrl+LoginUrl+params.toString());
      dio1.Response response = await dio.post(LoginUrl, data: params);
      print(response);
      if(response.statusCode==200){
        print("klkl"+LoginResponse.fromJson(response.data).toString());
        return LoginResponse.fromJson(response.data);
      }else{
        print("klkl121"+response.statusMessage.toString());
        return LoginResponse();
      }
    }catch(e){
      print(e.toString());
      return LoginResponse();
    }
  }

  Future<VerifyCodeResponse> verifyCode(String code)async{
    try {
      var LoginUrl="/verify_mobile";
      print(LoginUrl);
      var params={
        'code': code,
      };
      print(options.baseUrl+LoginUrl+params.toString());
      dio1.Response response = await dio.post(LoginUrl, data: params,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          ));
      print(response);
      if(response.statusCode==200){
        print("klkl"+VerifyCodeResponse.fromJson(response.data).toString());
        return VerifyCodeResponse.fromJson(response.data);
      }else{
        print("klkl121"+response.statusMessage.toString());
        return VerifyCodeResponse();
      }
    }catch(e){
      print(e.toString());
      return VerifyCodeResponse();
    }
  }

  Future<ResendCodeResponse> resendCode()async{
    try {
      var LoginUrl="/resend_code";
      print(LoginUrl);
      print(options.baseUrl+LoginUrl);
      dio1.Response response = await dio.post(LoginUrl,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("tokenUser"),
            },
          ));
      print(response);
      if(response.statusCode==200){
        print("klkl"+ResendCodeResponse.fromJson(response.data).toString());
        return ResendCodeResponse.fromJson(response.data);
      }else{
        print("klkl121"+response.statusMessage.toString());
        return ResendCodeResponse();
      }
    }catch(e){
      print(e.toString());
      return ResendCodeResponse();
    }
  }

  Future<CompleteUserInfoResponse> completeUserInfo(String name,
      String streetName,
      String type,String lat,String lng,
      String email,
      String phone)async{
    try {
      var Url="/update_user";
      print(Url);
      if(streetName==""){
        var params={
          'name': name,
          'email': email,
          'mobile': phone,
        };
        print(options.baseUrl+Url+params.toString());
        dio1.Response response = await dio.post(Url,data: params,
            options: dio1.Options(
              headers: {
                "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
                "Locale": sharedPreferencesService.getString("lang"),
                "Accept": "application/json",
              },
            ));
        print(response);
        print("klkl"+CompleteUserInfoResponse.fromJson(response.data).toString());
        return CompleteUserInfoResponse.fromJson(response.data);
      }else{
        var params={
          'name': name,
          'email': email,
          'mobile': phone,
          'street_name':streetName,
          'type':type,
          'lat':lat,
          'lng':lng,
        };
        print(options.baseUrl+Url+params.toString());
        dio1.Response response = await dio.post(Url,data: params,
            options: dio1.Options(
              headers: {
                "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
                "Locale": sharedPreferencesService.getString("lang"),
                "Accept": "application/json",
              },
            ));
        print(response);
        if(response.statusCode==200){
          print("klkl"+CompleteUserInfoResponse.fromJson(response.data).toString());
          return CompleteUserInfoResponse.fromJson(response.data);
        }else{
          print("klkl121"+response.statusMessage.toString());
          return CompleteUserInfoResponse();
        }
      }
    }on DioException  catch(e){
      print(e.toString());
      handleError(e);
      return CompleteUserInfoResponse();
    }
  }

  Future<dynamic> updateProfile(String name,String email,String mobile)async{
    try {
      var Url="/update_user";
      print(Url);
      var params ={
        'name': name,
        'email': email,
        'mobile':mobile,
      };
      print(options.baseUrl+Url+params.toString());
      dio1.Response response = await dio.post(Url,data: params,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
              "Accept": "application/json",
            },
          ));
      print(response);
      if(response.statusCode==200){
        print("klkl"+CompleteUserInfoResponse.fromJson(response.data).toString());
        return CompleteUserInfoResponse.fromJson(response.data);
      }else{
        print("klkl121"+response.statusMessage.toString());
        return CompleteUserInfoResponse();
      }
    }on DioException  catch(e){
      print(e.toString());
      handleError(e);
      return CompleteUserInfoResponse();
    }
  }


  Future<FaqsResponse> faqs(String type)async{
    try {
      var Url="/common/faqs";
      print(Url);
      print(Url);
      var params={
        'type': type,
      };
      print(options.baseUrl+Url+params.toString());
      dio1.Response response = await dio.post(Url,data: params,
          options: dio1.Options(
            headers: {
              // "authorization": "Bearer ${sharedPreferencesService.getString(
              //     "tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          )
      );
      print(response);
      return FaqsResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return FaqsResponse();
    }
  }

  Future<TermsAndConditionsResponse> termsAndCondition()async{
    try {
      var Url="/common/page/terms-and-conditions";
      print(Url);
      print(options.baseUrl+Url);
      dio1.Response response = await dio.get(Url,
          options: dio1.Options(
            headers: {
              // "authorization": "Bearer ${sharedPreferencesService.getString(
              //     "tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          )
      );
      print(response);
      return TermsAndConditionsResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return TermsAndConditionsResponse();
    }
  }

  Future<AboutAsResponse> aboutUs()async{
    try {
      var Url="/common/page/about-us";
      print(Url);
      print(options.baseUrl+Url);
      dio1.Response response = await dio.get(Url,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString(
                  "tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          )
      );
      print(response);
      return AboutAsResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return AboutAsResponse();
    }
  }

  Future<SocialResponse> getSocialLinks()async{
    try {
      var Url="/common/settings?";
      print(Url);
      var params={
        'keys[]': ["contact_us","social_media_links"],
      };
      print(options.baseUrl+Url+params.toString());
      dio1.Response response = await dio.get(Url,queryParameters: params,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString(
                  "tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          )
      );
      print(response);
      return SocialResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return SocialResponse();
    }
  }

  Future<AddressListResponse> getAddress()async{
    try {
      var Url="/addresses/list";
      print(Url);
      print(options.baseUrl+Url);
      dio1.Response response = await dio.get(Url,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          )
      );
      print(response);
      return AddressListResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return AddressListResponse();
    }
  }

  Future<DeleteResponse> deleteAddress(int id)async{
    try {
      var Url="/addresses/delete/$id";
      print(Url);
      print(options.baseUrl+Url);
      dio1.Response response = await dio.delete(Url,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          )
      );
      print(response);
      return DeleteResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return DeleteResponse();
    }
  }

  Future<AddAddressResponse> addAddress(String address,String lat,String lng,String type)async{
    try {
      var LoginUrl="/addresses/create";
      print(LoginUrl);
      var params={
        'street_name': address,
        'lat': lat,
        'lng': lng,
        'type': type,
      };
      print(options.baseUrl+LoginUrl+params.toString());
      dio1.Response response = await dio.post(LoginUrl,data: params,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          ));
      print(response);
      return AddAddressResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return AddAddressResponse();
    }
  }

  Future<EditAddressResponse> editAddress(String address,String lat,String lng,String type,int id)async{
    try {
      var LoginUrl="/addresses/update/$id";
      print(LoginUrl);
      var params={
        'street_name': address,
        'lat': lat,
        'lng': lng,
        'type': type,
      };
      print(options.baseUrl+LoginUrl+params.toString());
      dio1.Response response = await dio.post(LoginUrl,data: params,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          ));
      print(response);
      return EditAddressResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return EditAddressResponse();
    }
  }

  Future<BasketListResponse> getBaskets(String lat,String lng)async{
    try {
      var Url="/baskets?";
      var params={
        'lat': lat,
        'lng': lng
      };
      print(options.baseUrl+Url+params.toString());
      dio1.Response response = await dio.get(Url,queryParameters: params,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          )
      );
      print(response);
      return BasketListResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return BasketListResponse();
    }
  }

  Future<PreferencesResponse> getPreferences(String lat,String lng)async{
    try {
      var Url="/preferences?";
      var params={
        'lat': lat,
        'lng': lng
      };
      print(options.baseUrl+Url+params.toString());
      dio1.Response response = await dio.get(Url,queryParameters: params,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          )
      );
      print(response);
      return PreferencesResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return PreferencesResponse();
    }
  }

  Future<HomeResponse> getHomeData(String lat,String lng)async{
    try {
      var Url="/home_page?";
      var params={
        'lat': lat,
        'lng': lng
      };
      print(options.baseUrl+Url+params.toString());
      dio1.Response response = await dio.get(Url,queryParameters: params,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          )
      );
      print(response);
      return HomeResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return HomeResponse();
    }
  }

  Future<CreateOrderBasketResponse> createOrderBasket(
      int addressId,
      int couponId,
      String type,
      String deliveryDate,
      String payment,
      String notes,
      String totalAfterDiscount,
      String discount,
      String total,
      String products)async{
    try {
      var Url="/order/create";
      var params={
        'address_id': addressId,
        'coupon_id': couponId,
        'type':type,
        'delivery_date':deliveryDate,
        'payment':payment,
        'notes':notes,
        'total_after_discount':totalAfterDiscount,
        'discount':discount,
        'total':total,
        'products':products
      };
      print(options.baseUrl+Url+params.toString());
      dio1.Response response = await dio.post(Url,data: params,
          options: dio1.Options(
            headers: {
              "authorization": "Bearer ${sharedPreferencesService.getString("tokenUser")}",
              "Locale": sharedPreferencesService.getString("lang"),
            },
          )
      );
      print(response);
      return CreateOrderBasketResponse.fromJson(response.data);
    }catch(e){
      print(e.toString());
      return CreateOrderBasketResponse();
    }
  }

}