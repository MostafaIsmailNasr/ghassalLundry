import 'package:get/get_rx/get_rx.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

import '../../conustant/di.dart';
import '../../conustant/shared_preference_serv.dart';
import '../../data/reposatory/repo.dart';
import '../../data/web_service/WebServices.dart';

class DropOffController extends GetxController {
  Repo repo = Repo(WebService());
  final SharedPreferencesService sharedPreferencesService =
  instance<SharedPreferencesService>();
  var basketDate;
  var basketHours;
  var finalBasketTime="".obs;
  ///
  var subscriptionDate;
  var subscriptionHours;
  var finalsubscriptionTime="".obs;
  ///
  var upOnRequestDate;
  var upOnRequestHours;
  var finalupOnRequestTime="".obs;
  ///
  var homeBasketSubDate;
  var homeBasketSubHours;
  var finalHomeBasketSubTime="".obs;
}