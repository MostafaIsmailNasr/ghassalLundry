
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

import '../../conustant/di.dart';
import '../../conustant/shared_preference_serv.dart';
import '../../data/model/addressModel/addressListModel/AddressListResponse.dart';
import '../../data/model/basketModel/BasketListResponse.dart';
import '../../data/model/preferencesModel/PreferencesResponse.dart';
import '../../data/reposatory/repo.dart';
import '../../data/web_service/WebServices.dart';

class GhassalBasketsController extends GetxController {
  Repo repo = Repo(WebService());
  var basketListResponse = BasketListResponse().obs;
  var preferencesResponse = PreferencesResponse().obs;
  var addressListResponse = AddressListResponse().obs;
  var isLoading = false.obs;
  RxList<dynamic> basketList=[].obs;
  RxList<dynamic> preferencesList=[].obs;
  RxList<dynamic> addressList=[].obs;
  List<Baskets> basketItem = [];
  List<Preferences> preferencesItem = [];
  List<int> itemPrices = [];
  RxMap<int, int> itemPrices2 = RxMap<int, int>();
  List<int> itemPrefPrices = [];
  RxMap<int, int> itemPrefPrices2 = RxMap<int, int>();
  var quantityList=0.obs;
  var discount=0.0.obs;
  var CopunID;

  var isSelected=false;
  int? itemId=0;
  var isIroningSelected=true;
  int? itemIroningId=1;
  var addressType="";
  var lights=false;
  Rx<String> productsJson="".obs;
  Rx<String> prefersJson="".obs;

  TextEditingController codeController = TextEditingController();
  TextEditingController noteController = TextEditingController();
  final SharedPreferencesService sharedPreferencesService =
  instance<SharedPreferencesService>();

  ///
  var homeStreetName="".obs,homeAddressId;
  var workStreetName="".obs,workAddressId;
  var addressId;

  int getItemPrice(int productId) {
    return itemPrices2[productId] ?? 0;
  }

  getBasketsList(String lat, String lng)async{
    isLoading.value=true;
    basketListResponse.value = await repo.getBaskets(lat, lng);
    if(basketListResponse.value.success==true){
      isLoading.value=false;
      basketList.value=basketListResponse.value.data?.baskets as List;
      getPreferences(lat,lng);
    }
    return basketListResponse.value;
  }

  getPreferences(String lat,String lng)async{
    isLoading.value=true;
    preferencesResponse.value = await repo.getPreferences(lat, lng);
    if(preferencesResponse.value.success==true){
      isLoading.value=false;
      preferencesList.value=preferencesResponse.value.data?.preferences as List;
    }
    return preferencesResponse.value;
  }

  getAddressList(BuildContext context)async{
    isLoading.value=true;
    addressListResponse.value = await repo.getAddress();
    if(addressListResponse.value.success==true){
      isLoading.value=false;
      addressList.value=addressListResponse.value.data as List;
      if(addressListResponse.value.data!.isEmpty){

      }else{
        bool homeAddressFound = false;
        bool workAddressFound = false;
        for(int i=0;i<addressList.length;i++){
          if (!homeAddressFound &&addressListResponse.value.data?[i].type == 'home') {
            // Store the home address details
            homeStreetName.value = addressListResponse.value.data?[i].streetName ?? "";
            homeAddressId = addressListResponse.value.data?[i].id;
            homeAddressFound=true;
          }  if (!workAddressFound &&addressListResponse.value.data?[i].type == 'work') {
            workStreetName.value = addressListResponse.value.data?[i].streetName ?? "";
            print("ccccx "+workStreetName.value.toString());
            workAddressId = addressListResponse.value.data?[i].id;
            workAddressFound=true;
          }
          // Break the loop if both home and work addresses are found
          if (homeAddressFound && workAddressFound) {
            break;
          }
        }
      }
    }
    return addressListResponse.value;
  }

  String convertBasketListToJson(List<Baskets> productsList) {
    List<Map<String, dynamic>> productListJson = [];
    productsList.forEach((product) {
      productListJson.add({
        'basket_id': product.id,
        'price':isIroningSelected==true&&itemIroningId==1?
        product.priceWash ?? 0:product.priceIroning ?? 0,
        'quantity': product.quantity,
        'wash_type':isIroningSelected==true&&itemIroningId==1?0:1,
        'type':"baskets"
      });
    });
    return jsonEncode(productListJson);
  }

  String convertPreListToJson(List<Preferences> productsList) {
    List<Map<String, dynamic>> productListJson = [];
    productsList.forEach((product) {
      productListJson.add({
        'id': product.id,
        'price': product.price ?? 0
      });
    });
    return jsonEncode(productListJson);
  }
}