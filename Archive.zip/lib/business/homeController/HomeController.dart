
import 'package:get/get_rx/get_rx.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

import '../../conustant/di.dart';
import '../../conustant/shared_preference_serv.dart';
import '../../data/model/homeModel/HomeResponse.dart';
import '../../data/reposatory/repo.dart';
import '../../data/web_service/WebServices.dart';

class HomeController extends GetxController {
  Repo repo = Repo(WebService());
  var homeResponse = HomeResponse().obs;
  var isLoading = false.obs;
  RxList<dynamic> popupList=[].obs;
  RxList<dynamic> sliderList=[].obs;
  var popUpImg= "".obs;
  RxList<dynamic> mySubscriptionsList=[].obs;

  final SharedPreferencesService sharedPreferencesService =
  instance<SharedPreferencesService>();
  var lang="";
  var isLogin;
  String currentAddress = '';
  late double lat=30.0622723;
  late double lng=31.3274007;

  getData()async{
    lang=sharedPreferencesService.getString("lang");
    isLogin=sharedPreferencesService.getBool("isLogin");
  }

  getHomeData(String lat,String lng)async{
    isLoading.value=true;
    homeResponse.value = await repo.getHomeData(lat, lng);
    if(homeResponse.value.success==true){
      isLoading.value=false;
      popupList.value=homeResponse.value.data?.advertising as List;
      if(popupList.value.isNotEmpty) {
        popUpImg.value = homeResponse.value.data?.advertising?[0].image ?? "";
      }
      print("imgjkio "+popUpImg.value.toString());
      sliderList.value=homeResponse.value.data?.sliders as List;
      mySubscriptionsList.value=homeResponse.value.data?.mySubscribtions as List;
    }
    return homeResponse.value;
  }
}