import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:sizer/sizer.dart';
import 'dart:math' as math;
import 'package:localize_and_translate/localize_and_translate.dart';

import '../../../../business/auth/registerController/RegisterController.dart';
import '../../../../business/dropOffController/DropOffController.dart';
import '../../../../business/ghassalSubscriptionController/GhassalSubscriptionController.dart';
import '../../../../business/homeController/HomeController.dart';
import '../../../../conustant/my_colors.dart';
import '../../buttomNavigation/drower.dart';
import '../../buttomSheets/dropDownTimeButtomSheet/drop_down_time_buttomSheet.dart';

class HomeBasketSubScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _HomeBasketSubScreen();
  }
}

class _HomeBasketSubScreen extends State<HomeBasketSubScreen>{
  final ButtonStyle flatButtonStyle = TextButton.styleFrom(
      backgroundColor: MyColors.MainPrimary,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(15)),
      ));
  final homeController = Get.put(HomeController());
  final registerController = Get.put(RegisterController());
  final dropOffController = Get.put(DropOffController());
  final ghassalSubscriptionController = Get.put(GhassalSubscriptionController());
  List<bool> checkedList = List.generate(3, (index) => false);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) {
      clearData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Transform.rotate(
                angle:homeController.lang=="en"? 180 *math.pi /180:0,
                child: SvgPicture.asset('assets/back.svg',))),
        title: Text('subscription_package'.tr(),
            style: TextStyle(
                fontSize: 12.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color: MyColors.MainBulma)),
      ),
      body: Container(
        margin: EdgeInsetsDirectional.only(start: 2.h,end: 2.h,top: 1.h),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              address(),
              SizedBox(height: 2.h,),
              receivingDate(),
              SizedBox(height: 1.h,),
              Text("preferences".tr(),
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_bold',
                      fontWeight: FontWeight.w500,
                      color:MyColors.MainBulma)),
              SizedBox(height: 1.h,),
              preferencesList(),
              SizedBox(height: 1.h,),
              notes(),
              SizedBox(height: 2.h,),
            ],
          ),
        ),
      ),
      bottomNavigationBar:  Container(
          color: Colors.white,
          height: 9.h,
          child:
          Container(
            margin: EdgeInsetsDirectional.only(start: 1.h, end: 1.h,bottom: 1.h),
            width: double.infinity,
            height: 7.h,
            child: TextButton(
              style: flatButtonStyle,
              onPressed: () async {
                onAlertButtonsPressed(context);
              },
              child: Text(
                'request'.tr(),
                style: TextStyle(
                    fontSize: 12.sp,
                    fontFamily: 'regular',
                    fontWeight: FontWeight.w500,
                    color: Colors.white),
              ),
            ),
          )
      ),
    );
  }

  Widget address(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("receiving_address".tr(),
            style:  TextStyle(fontSize: 11.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color:MyColors.MainBulma)),
        SizedBox(height: 1.h,),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: GestureDetector(
                onTap: (){
                  setState(() {
                    ghassalSubscriptionController.isSelectedAddress=true;
                    ghassalSubscriptionController.addressType="home";
                    ghassalSubscriptionController.itemIdAddress=1;
                  });
                },
                child: Container(
                  height: 6.h,
                  padding: EdgeInsetsDirectional.all(0.5.h),
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(15)),
                      border: Border.all(
                        color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==1?MyColors.MainPrimary: MyColors.MainDisabledPrimary ,
                        width: 1.0,),
                      color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==1?MyColors.timeBack: Colors.white),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset("assets/home_smile.svg",color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==1?MyColors.MainPrimary: MyColors.MainDisabledPrimary,),
                      SizedBox(width: 1.h,),
                      Text("home2".tr(),
                          style:  TextStyle(fontSize: 8.sp,
                              fontFamily: 'alexandria_medium',
                              fontWeight: FontWeight.w400,
                              color:ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==1?MyColors.MainPrimary: MyColors.MainDisabledPrimary)),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(width: 1.h,),
            Expanded(
              child: GestureDetector(
                onTap: (){
                  setState(() {
                    ghassalSubscriptionController.isSelectedAddress=true;
                    ghassalSubscriptionController.addressType="office";
                    ghassalSubscriptionController.itemIdAddress=2;
                  });
                },
                child: Container(
                  height: 6.h,
                  padding: EdgeInsetsDirectional.all(0.5.h),
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(15)),
                      border: Border.all(
                        color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==2?MyColors.MainPrimary: MyColors.MainDisabledPrimary,
                        width: 1.0,),
                      color:  ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==2?MyColors.timeBack: Colors.white),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset("assets/buildings.svg",color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==2?MyColors.MainPrimary: MyColors.MainDisabledPrimary),
                      SizedBox(width: 1.h,),
                      Text("office".tr(),
                          style:  TextStyle(fontSize: 8.sp,
                              fontFamily: 'alexandria_medium',
                              fontWeight: FontWeight.w400,
                              color:ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==2?MyColors.MainPrimary: MyColors.MainDisabledPrimary)),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(width: 1.h,),
            Expanded(
              child: GestureDetector(
                onTap: (){
                  setState(() {
                    ghassalSubscriptionController.isSelectedAddress=true;
                    ghassalSubscriptionController.addressType="another_address";
                    ghassalSubscriptionController.itemIdAddress=3;
                    Navigator.pushNamed(context, "/location_screen",arguments: "subscription");
                  });
                },
                child: Container(
                  height: 6.h,
                  padding: EdgeInsetsDirectional.all(0.5.h),
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(15)),
                      border: Border.all(
                        color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==3?MyColors.MainPrimary: MyColors.MainDisabledPrimary,
                        width: 1.0,),
                      color:  ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==3?MyColors.timeBack: Colors.white),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SvgPicture.asset("assets/map0.svg",color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==3?MyColors.MainPrimary: MyColors.MainDisabledPrimary,),
                      SizedBox(width: 1.h,),
                      Text("another_address".tr(),
                          style:  TextStyle(fontSize: 8.sp,
                              fontFamily: 'alexandria_medium',
                              fontWeight: FontWeight.w400,
                              color:ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==3?MyColors.MainPrimary: MyColors.MainDisabledPrimary)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h,),
        Row(
          children: [
            SvgPicture.asset('assets/location2.svg',width: 2.h,height: 2.h,),
            SizedBox(width: 2.w,),
            SizedBox(
                width: 30.h,
                child:Obx(() =>registerController.address2.value!=""? Text(
                  registerController.address2.value.toString(),
                  style:  TextStyle(fontSize: 8.sp,
                      fontFamily: 'alexandria_regular',
                      fontWeight: FontWeight.w300,
                      color:MyColors.MainTrunks),maxLines: 2,)
                    :Text('add_delivery_location'.tr(),
                  style:TextStyle(fontSize: 8.sp,
                      fontFamily: 'alexandria_regular',
                      fontWeight: FontWeight.w300,
                      color:MyColors.MainTrunks),maxLines: 2,),
                )),

          ],
        ),
      ],
    );
  }

  Widget receivingDate(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("receiving_date".tr(),
            style:  TextStyle(fontSize: 11.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color:MyColors.MainBulma)),
        SizedBox(height: 1.h,),
        GestureDetector(
          onTap: (){
            showModalBottomSheet<void>(
                isScrollControlled: true,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                context: context,
                backgroundColor: Colors.white,
                builder: (BuildContext context) =>
                    Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery
                                .of(context)
                                .viewInsets
                                .bottom),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            dropDownTimeButtomSheet(
                              from: "homeBasketSub",),
                          ],
                        )));
          },
          child: Container(
            padding: EdgeInsetsDirectional.all(1.5.h),
            margin: EdgeInsetsDirectional.only(bottom: 1.h),
            decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(Radius.circular(15)),
                border: Border.all(
                  color:MyColors.MainGoku, width: 1,),
                color:  Colors.white),
            child: Row(
              children: [
                SvgPicture.asset("assets/calendar.svg"),
                SizedBox(width: 1.h,),
                SizedBox(
                  width: 32.h,
                  child:Obx(() => dropOffController.finalHomeBasketSubTime.value!=""?
                  Text(dropOffController.finalHomeBasketSubTime.value,
                      style:  TextStyle(fontSize: 12.sp,
                          fontFamily: 'alexandria_regular',
                          fontWeight: FontWeight.w300,
                          color:MyColors.MainTrunks))
                      : Text('select_date'.tr(),
                      style:  TextStyle(fontSize: 12.sp,
                          fontFamily: 'alexandria_regular',
                          fontWeight: FontWeight.w300,
                          color:MyColors.MainTrunks))),
                ),
                const Spacer(),
                Transform.rotate(
                    angle:homeController.lang=="en"? 180 *math.pi /180:0,
                    child: SvgPicture.asset('assets/alt_arrow.svg',))
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget preferencesList() {
    //if (homeController.brandsList.isNotEmpty) {
    return ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        physics: const ScrollPhysics(),
        itemCount: checkedList.length,//homeController.brandsList.length,
        itemBuilder: (context, int index) {
          return Container(
            padding: EdgeInsetsDirectional.all(1.5.h),
            margin: EdgeInsetsDirectional.only(bottom: 1.h),
            decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(Radius.circular(15)),
                border: Border.all(
                    color: MyColors.MainGoku,
                    width: 2.0),
                color:  Colors.white),
            child: Row(
              children: [
                SvgPicture.asset('assets/leaf.svg'),
                SizedBox(width: 1.h,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("غسيل عضوي",
                        style:  TextStyle(fontSize: 12.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w300,
                            color:MyColors.MainBulma)),
                    SizedBox(height: 1.h,),
                    Text("غير مثير للحساسية وبدون روائح",
                        style:  TextStyle(fontSize: 8.sp,
                            fontFamily: 'alexandria_regular',
                            fontWeight: FontWeight.w300,
                            color:MyColors.MainTrunks)),
                  ],
                ),
                const Spacer(),
                Checkbox(
                  checkColor: Colors.white,
                  value: checkedList[index],
                  activeColor: MyColors.MainPrimary,
                  onChanged: (bool? isChecked) {
                    setState(() {
                      checkedList[index] = isChecked!;
                    });
                  },
                ),
              ],
            ),
          );
        }
    );
    // } else {
    //   return Container();
    // }
  }

  Widget notes(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("notes".tr(),
            style:  TextStyle(fontSize: 11.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color:MyColors.MainBulma)),
        SizedBox(height: 1.h,),
        Container(
          height: 15.h,
          decoration: BoxDecoration(
              borderRadius: const BorderRadius.all(Radius.circular(15)),
              border: Border.all(
                color: MyColors.MainGoku,
                width: 1.0,
              ),
              color:Colors.white),
          child: TextFormField(
            maxLines: 4,
            autovalidateMode:AutovalidateMode.onUserInteraction ,
            controller: ghassalSubscriptionController.noteController,
            decoration:   InputDecoration(
              errorBorder:  const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(15)),
                borderSide: BorderSide(color: Colors.red,style: BorderStyle.solid),
              ),
              enabledBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(15)),
                borderSide: BorderSide(color: MyColors.MainGoku,style: BorderStyle.solid),
              ),
              focusedBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(15)),
                  borderSide: BorderSide(style: BorderStyle.solid,color: MyColors.MainGoku,)
              ),
              focusedErrorBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(15)),
                borderSide: BorderSide(color: Colors.red,style: BorderStyle.solid),
              ) ,
              hintText: 'write'.tr(),
              hintStyle: TextStyle(fontSize: 12.sp,
                  fontFamily: 'lexend_regular',
                  fontWeight: FontWeight.w400,
                  color: MyColors.MainTrunks),
            ),
            style:  TextStyle(fontSize: 12.sp,
                fontFamily: 'alexandria_regular',
                fontWeight: FontWeight.w400,
                color: MyColors.MainZeno),
          ),
        )
      ],
    );
  }

  clearData(){
    dropOffController.homeBasketSubHours="";
    dropOffController.homeBasketSubDate="";
    dropOffController.finalHomeBasketSubTime.value="";
    ghassalSubscriptionController.noteController.clear();
    ghassalSubscriptionController.isSelectedAddress=false;
    ghassalSubscriptionController.addressType="";
    ghassalSubscriptionController.itemIdAddress=-1;
    ghassalSubscriptionController.isSelected=false;
    ghassalSubscriptionController.itemId=-1;
    registerController.address2.value="";
  }

  onAlertButtonsPressed(context) {
    Alert(
      context: context,
      image: SvgPicture.asset('assets/success2.svg',),
      title: 'basket_ordered'.tr(),
      style:  AlertStyle(
          titleStyle:TextStyle(fontSize: 12.sp,
              fontFamily: 'alexandria_bold',
              fontWeight: FontWeight.w500,
              color: MyColors.MainBulma),
          descStyle: TextStyle(fontSize: 10.sp,
              fontFamily: 'alexandria_regular',
              fontWeight: FontWeight.w300,
              color: MyColors.MainTrunks)
      ),
      desc: "لقد تمت طلب السلة في اشتراكك متبقي لك 4 سلال",//'the_order_was_made_successfully2'.tr(),
      buttons: [
        DialogButton(
          radius: BorderRadius.circular(15),
          height: 7.h,
          onPressed: ()  {
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) {
                  return DrowerPage(index: 0,);
                }));
          },
          color: MyColors.MainPrimary,
          child: Text('home'.tr(),
              style:  TextStyle(
                  fontSize: 12.sp,
                  fontFamily: 'regular',
                  fontWeight: FontWeight.w500,
                  color: Colors.white)),
        ),
      ],
    ).show();
  }


}