import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:sizer/sizer.dart';

import '../../../../../conustant/my_colors.dart';
import 'package:localize_and_translate/localize_and_translate.dart';

import '../../../../widget/basket/basketsList/BasketsItem.dart';

class SelectedBasketScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _SelectedBasketScreen();
  }
}

class _SelectedBasketScreen extends State<SelectedBasketScreen>{
  var selectedFlage=0;
  var isSelected=false;
  int? itemId=0;
  List<bool> checkedList = List.generate(6, (index) => false);
  final ButtonStyle flatButtonStyle = TextButton.styleFrom(
      backgroundColor: MyColors.MainPrimary,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(15)),
      ));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColors.BGColor,
      body: SafeArea(
        child: Container(
          margin: EdgeInsetsDirectional.only(start: 2.h,end: 2.h,top: 2.h),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                customBar(),
                SizedBox(height: 2.h,),
                Text("number_baskets".tr(),
                    style:  TextStyle(fontSize: 10.sp,
                        fontFamily: 'alexandria_bold',
                        fontWeight: FontWeight.w500,
                        color:MyColors.MainBulma)),
                SizedBox(height: 1.h,),
                basketsList(),
                SizedBox(height: 1.h,),
                Text("ironing_baskets".tr(),
                    style:  TextStyle(fontSize: 10.sp,
                        fontFamily: 'alexandria_bold',
                        fontWeight: FontWeight.w500,
                        color:MyColors.MainBulma)),
                SizedBox(height: 1.h,),
                ironingBaskets(),
                SizedBox(height: 1.h,),
                Text("preferences".tr(),
                    style:  TextStyle(fontSize: 10.sp,
                        fontFamily: 'alexandria_bold',
                        fontWeight: FontWeight.w500,
                        color:MyColors.MainBulma)),
                SizedBox(height: 1.h,),
                preferencesList()
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
          color: Colors.white,
          margin: EdgeInsetsDirectional.all(1.h),
          height: 8.h,
          child:
          Container(
            margin: EdgeInsetsDirectional.only(start: 1.h, end: 1.h,),
            width: double.infinity,
            height: 7.h,
            child: TextButton(
              style: flatButtonStyle,
              onPressed: () async {

              },
              child: Text(
                'confirm'.tr(),
                style: TextStyle(
                    fontSize: 12.sp,
                    fontFamily: 'regular',
                    fontWeight: FontWeight.w500,
                    color: Colors.white),
              ),
            ),
          )
      ),
    );
  }

  Widget customBar(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text("customize_baskets".tr(),
            style:  TextStyle(fontSize: 12.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color:MyColors.MainBulma)),
        GestureDetector(
          onTap: (){
            Navigator.pop(context);
          },
          child: SvgPicture.asset('assets/close_circle2.svg'),
        ),
      ],
    );
  }

  Widget basketsList() {
    //if (homeController.brandsList.isNotEmpty) {
    return SizedBox(
      height: 25.h,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          shrinkWrap: true,
          physics: const ScrollPhysics(),
          itemCount: 3,//homeController.brandsList.length,
          itemBuilder: (context, int index) {
            return BasketsItem(
              is_selected: selectedFlage==index,
              onTap: () {
                setState(() {
                  selectedFlage=index;
                });
              },
              baskets: null,
            );
          }
      ),
    );
    // } else {
    //   return Container();
    // }
  }

  Widget ironingBaskets(){
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: (){
              setState(() {
                isSelected=true;
                itemId=1;
              });
            },
            child: Container(
              padding: EdgeInsetsDirectional.all(2.h),
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(15)),
                  border: Border.all(
                    color:isSelected==true && itemId==1?MyColors.MainPrimary: MyColors.MainGoku,
                    width:isSelected==true && itemId==1? 2.0: 1.0,),
                  color:  Colors.white),
              child: Row(
                children: [
                  isSelected==true && itemId==1?SvgPicture.asset('assets/radio_selected.svg'):
                  SvgPicture.asset('assets/radio_button.svg'),
                  SizedBox(width: 1.h,),
                  Expanded(
                    child: Text("washing_ironing".tr(),
                        style:  TextStyle(fontSize: 8.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w400,
                            color:MyColors.MainBulma)),
                  ),
                ],
              ),
            ),
          ),
        ),
        SizedBox(width: 1.h,),
        Expanded(
          child: GestureDetector(
            onTap: (){
              setState(() {
                isSelected=true;
                itemId=2;
              });
            },
            child: Container(
              padding: EdgeInsetsDirectional.all(2.h),
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(15)),
                  border: Border.all(
                    color: isSelected==true && itemId==2?MyColors.MainPrimary: MyColors.MainGoku,
                    width:isSelected==true && itemId==2?2.0: 1.0,),
                  color:  Colors.white),
              child: Row(
                children: [
                  isSelected==true && itemId==2?SvgPicture.asset('assets/radio_selected.svg'):
                  SvgPicture.asset('assets/radio_button.svg'),
                  SizedBox(width: 1.h,),
                  Text("iron_only".tr(),
                      style:  TextStyle(fontSize: 8.sp,
                          fontFamily: 'alexandria_medium',
                          fontWeight: FontWeight.w400,
                          color:MyColors.MainBulma)),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget preferencesList() {
    //if (homeController.brandsList.isNotEmpty) {
    return ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        physics: const ScrollPhysics(),
        itemCount: checkedList.length,//homeController.brandsList.length,
        itemBuilder: (context, int index) {
          return Container(
            padding: EdgeInsetsDirectional.all(1.5.h),
            margin: EdgeInsetsDirectional.only(bottom: 1.h),
            decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(Radius.circular(15)),
                border: Border.all(
                    color: MyColors.MainGoku,
                    width: 2.0),
                color:  Colors.white),
            child: Row(
              children: [
                SvgPicture.asset('assets/leaf.svg'),
                SizedBox(width: 1.h,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("غسيل عضوي",
                        style:  TextStyle(fontSize: 12.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w300,
                            color:MyColors.MainBulma)),
                    SizedBox(height: 1.h,),
                    Text("غير مثير للحساسية وبدون روائح",
                        style:  TextStyle(fontSize: 8.sp,
                            fontFamily: 'alexandria_regular',
                            fontWeight: FontWeight.w300,
                            color:MyColors.MainTrunks)),
                  ],
                ),
                const Spacer(),
                Checkbox(
                  checkColor: Colors.white,
                  value: checkedList[index],
                  activeColor: MyColors.MainPrimary,
                  onChanged: (bool? isChecked) {
                    setState(() {
                      checkedList[index] = isChecked!;
                    });
                  },
                ),
              ],
            ),
          );
        }
    );
    // } else {
    //   return Container();
    // }
  }

}