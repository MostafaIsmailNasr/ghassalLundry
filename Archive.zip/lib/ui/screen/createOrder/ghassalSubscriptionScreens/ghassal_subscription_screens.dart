import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:sizer/sizer.dart';

import '../../../../business/auth/registerController/RegisterController.dart';
import '../../../../business/dropOffController/DropOffController.dart';
import '../../../../business/ghassalSubscriptionController/GhassalSubscriptionController.dart';
import '../../../../business/homeController/HomeController.dart';
import '../../../../conustant/my_colors.dart';
import 'dart:math' as math;
import 'package:localize_and_translate/localize_and_translate.dart';

import '../../../widget/subscription/selectBasket/SelectBasketItem.dart';
import '../../../widget/subscription/subscriptionList/SubscriptionItem.dart';
import 'package:dotted_border/dotted_border.dart';

import '../../buttomNavigation/drower.dart';
import '../../buttomSheets/authSheets/auth/auth_buttom_sheet.dart';
import '../../buttomSheets/dropDownTimeButtomSheet/drop_down_time_buttomSheet.dart';


class GhassalSubscriptionScreens extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _GhassalSubscriptionScreens();
  }
}

class _GhassalSubscriptionScreens extends State<GhassalSubscriptionScreens>{
  var selectedFlage=-1;
  var selectedFlageBasket=0;
  var isBasketVisible=false;
  final _formKey = GlobalKey<FormState>();
  final ButtonStyle flatButtonStyle = TextButton.styleFrom(
      backgroundColor: MyColors.MainPrimary,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(15)),
      ));
  List<bool> checkedList = List.generate(3, (index) => false);

  final homeController = Get.put(HomeController());
  final dropOffController = Get.put(DropOffController());
  final ghassalSubscriptionController = Get.put(GhassalSubscriptionController());
  final registerController = Get.put(RegisterController());

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) {
      clearData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor:  Colors.white,
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Transform.rotate(
                angle:homeController.lang=="en"? 180 *math.pi /180:0,
                child: SvgPicture.asset('assets/back.svg',))),
        title: Text('ghassal_subscriptions'.tr(),
            style: TextStyle(
                fontSize: 12.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color: MyColors.MainBulma)),
      ),
      body: Container(
        margin: EdgeInsetsDirectional.only(start: 2.h,end: 2.h,top: 1.h),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("subscription_type".tr(),
                  style:  TextStyle(fontSize: 11.sp,
                      fontFamily: 'alexandria_bold',
                      fontWeight: FontWeight.w500,
                      color:MyColors.MainBulma)),
              SizedBox(height: 1.h,),
              subscriptionList(),
              SizedBox(height: 1.h,),
              Visibility(
                visible: isBasketVisible,
                  child: basketsList()),
              SizedBox(height: 1.h,),
              Text("ironing_baskets".tr(),
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_bold',
                      fontWeight: FontWeight.w500,
                      color:MyColors.MainBulma)),
              SizedBox(height: 1.h,),
              ironingBaskets(),
              SizedBox(height: 1.h,),
              address(),
              SizedBox(height: 1.h,),
              receivingDate(),
              SizedBox(height: 1.h,),
              coupon(),
              SizedBox(height: 1.h,),
              payment(),
              SizedBox(height: 1.h,),
              Text("preferences".tr(),
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_bold',
                      fontWeight: FontWeight.w500,
                      color:MyColors.MainBulma)),
              SizedBox(height: 1.h,),
              preferencesList(),
              SizedBox(height: 1.h,),
              notes(),
              SizedBox(height: 3.h,),
            ],
          ),
        ),
      ),
      bottomNavigationBar:  Container(
          color: Colors.white,
          height: 9.h,
          child:
          Row(
            children: [
              Expanded(
                flex: 2,
                child: Container(
                  margin: EdgeInsetsDirectional.only(start: 1.h, end: 1.h,),
                  width: double.infinity,
                  height: 7.h,
                  child: TextButton(
                    style: flatButtonStyle,
                    onPressed: () async {
                      if(ghassalSubscriptionController.sharedPreferencesService.getBool("islogin")==false){
                        showModalBottomSheet<void>(
                            isScrollControlled: true,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                            ),
                            context: context,
                            backgroundColor: Colors.white,
                            builder: (BuildContext context) => Padding(
                                padding: EdgeInsets.only(
                                    bottom: MediaQuery.of(context).viewInsets.bottom),
                                child: AuthButtomSheet(from: "subscription",)));
                      }else{
                        onAlertButtonsPressed(context);
                      }
                    },
                    child: Text(
                      'confirm_subscription'.tr(),
                      style: TextStyle(
                          fontSize: 12.sp,
                          fontFamily: 'regular',
                          fontWeight: FontWeight.w500,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 1.h,),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("total".tr(),
                        style:  TextStyle(fontSize: 8.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w400,
                            color:MyColors.MainTrunks)),
                    Text("200 SAR",
                        style:  TextStyle(fontSize: 14.sp,
                            fontFamily: 'alexandria_bold',
                            fontWeight: FontWeight.w400,
                            color:MyColors.MainZeno)),
                  ],
                ),)
            ],)
      ),
    );
  }

  Widget subscriptionList(){
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        height: 18.h,
        child: Row(
          children: [
            ListView.builder(
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                itemCount: 3,//homeController.brandsList.length,
                itemBuilder: (context, int index) {
                  return SubscriptionItem(
                    is_selected: selectedFlage==index,
                    onTap: () {
                      setState(() {
                        selectedFlage=index;
                        isBasketVisible=true;
                      });
                    },
                  );
                }
            ),
            GestureDetector(
              onTap: (){
                setState(() {
                  ghassalSubscriptionController.isSelected=false;
                  ghassalSubscriptionController.itemId=-1;
                  isBasketVisible=false;
                });

                Navigator.pushNamed(context, '/customize_package_screens');
              },
              child: DottedBorder(
                borderType: BorderType.RRect,
                radius: const Radius.circular(15),
                color: MyColors.MainPrimary,//color of dotted/dash line
                strokeWidth: 1, //thickness of dash/dots
                dashPattern: const [10,6],
                child: Container(
                  margin: EdgeInsetsDirectional.only(end: 1.h,bottom: 1.h),
                  padding: EdgeInsetsDirectional.all(0.5.h),
                  height: 15.h,
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(15)),
                      border: Border.all(
                        color:  MyColors.MainGohan,
                        width: 1.0,),
                      color: MyColors.MainGohan),
                  child: Center(
                    child: Text("more_baskets".tr(),
                        style:  TextStyle(fontSize: 12.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w500,
                            color:MyColors.MainPrimary)),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget basketsList(){
    return SizedBox(
      height: 10.h,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          shrinkWrap: true,
          physics: const ScrollPhysics(),
          itemCount: 3,//homeController.brandsList.length,
          itemBuilder: (context, int index) {
            return SelectBasketItem(
              is_selected: selectedFlageBasket==index,
              onTap: () {
                setState(() {
                  selectedFlageBasket=index;
                });
              },
            );
          }
      ),
    );
  }

  Widget ironingBaskets(){
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: (){
              setState(() {
                ghassalSubscriptionController.isSelected=true;
                ghassalSubscriptionController.itemId=1;
              });
            },
            child: Container(
              padding: EdgeInsetsDirectional.all(2.h),
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(15)),
                  border: Border.all(
                    color:ghassalSubscriptionController.isSelected==true && ghassalSubscriptionController.itemId==1?MyColors.MainPrimary: MyColors.MainGoku,
                    width:ghassalSubscriptionController.isSelected==true && ghassalSubscriptionController.itemId==1? 2.0: 1.0,),
                  color:  Colors.white),
              child: Row(
                children: [
                  ghassalSubscriptionController.isSelected==true && ghassalSubscriptionController.itemId==1?SvgPicture.asset('assets/radio_selected.svg'):
                  SvgPicture.asset('assets/radio_button.svg'),
                  SizedBox(width: 1.h,),
                  Expanded(
                    child: Text("washing_ironing".tr(),
                        style:  TextStyle(fontSize: 8.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w400,
                            color:MyColors.MainBulma)),
                  ),
                ],
              ),
            ),
          ),
        ),
        SizedBox(width: 1.h,),
        Expanded(
          child: GestureDetector(
            onTap: (){
              setState(() {
                ghassalSubscriptionController.isSelected=true;
                ghassalSubscriptionController.itemId=2;
              });
            },
            child: Container(
              padding: EdgeInsetsDirectional.all(2.h),
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(15)),
                  border: Border.all(
                    color: ghassalSubscriptionController.isSelected==true && ghassalSubscriptionController.itemId==2?MyColors.MainPrimary: MyColors.MainGoku,
                    width:ghassalSubscriptionController.isSelected==true && ghassalSubscriptionController.itemId==2?2.0: 1.0,),
                  color:  Colors.white),
              child: Row(
                children: [
                  ghassalSubscriptionController.isSelected==true && ghassalSubscriptionController.itemId==2?SvgPicture.asset('assets/radio_selected.svg'):
                  SvgPicture.asset('assets/radio_button.svg'),
                  SizedBox(width: 1.h,),
                  Text("iron_only".tr(),
                      style:  TextStyle(fontSize: 8.sp,
                          fontFamily: 'alexandria_medium',
                          fontWeight: FontWeight.w400,
                          color:MyColors.MainBulma)),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget address(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("receiving_address".tr(),
            style:  TextStyle(fontSize: 11.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color:MyColors.MainBulma)),
        SizedBox(height: 1.h,),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: GestureDetector(
                onTap: (){
                  setState(() {
                    ghassalSubscriptionController.isSelectedAddress=true;
                    ghassalSubscriptionController.addressType="home";
                    ghassalSubscriptionController.itemIdAddress=1;
                  });
                },
                child: Container(
                  height: 6.h,
                  padding: EdgeInsetsDirectional.all(0.5.h),
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(15)),
                      border: Border.all(
                        color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==1?MyColors.MainPrimary: MyColors.MainSecondary ,
                        width: 1.0,),
                      color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==1?MyColors.MainGohan: Colors.white),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset("assets/home_smile.svg",color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==1?MyColors.MainPrimary: MyColors.MainSecondary,),
                      SizedBox(width: 1.h,),
                      Text("home2".tr(),
                          style:  TextStyle(fontSize: 8.sp,
                              fontFamily: 'alexandria_medium',
                              fontWeight: FontWeight.w400,
                              color:ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==1?MyColors.MainPrimary: MyColors.MainSecondary)),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(width: 1.h,),
            Expanded(
              child: GestureDetector(
                onTap: (){
                  setState(() {
                    ghassalSubscriptionController.isSelectedAddress=true;
                    ghassalSubscriptionController.addressType="office";
                    ghassalSubscriptionController.itemIdAddress=2;
                  });
                },
                child: Container(
                  height: 6.h,
                  padding: EdgeInsetsDirectional.all(0.5.h),
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(15)),
                      border: Border.all(
                        color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==2?MyColors.MainPrimary: MyColors.MainSecondary,
                        width: 1.0,),
                      color:  ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==2?MyColors.MainGohan: Colors.white),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset("assets/buildings.svg",color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==2?MyColors.MainPrimary: MyColors.MainSecondary),
                      SizedBox(width: 1.h,),
                      Text("office".tr(),
                          style:  TextStyle(fontSize: 8.sp,
                              fontFamily: 'alexandria_medium',
                              fontWeight: FontWeight.w400,
                              color:ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==2?MyColors.MainPrimary: MyColors.MainSecondary)),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(width: 1.h,),
            Expanded(
              child: GestureDetector(
                onTap: (){
                  setState(() {
                    ghassalSubscriptionController.isSelectedAddress=true;
                    ghassalSubscriptionController.addressType="another_address";
                    ghassalSubscriptionController.itemIdAddress=3;
                    Navigator.pushNamed(context, "/location_screen",arguments: "subscription");
                  });
                },
                child: Container(
                  height: 6.h,
                  padding: EdgeInsetsDirectional.all(0.5.h),
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(15)),
                      border: Border.all(
                        color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==3?MyColors.MainPrimary: MyColors.MainSecondary,
                        width: 1.0,),
                      color:  ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==3?MyColors.MainGohan: Colors.white),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset("assets/map0.svg",color: ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==3?MyColors.MainPrimary: MyColors.MainSecondary,),
                      SizedBox(width: 1.h,),
                      Expanded(
                        child: Text("another_address".tr(),
                            style:  TextStyle(fontSize: 8.sp,
                                fontFamily: 'alexandria_medium',
                                fontWeight: FontWeight.w400,
                                color:ghassalSubscriptionController.isSelectedAddress==true && ghassalSubscriptionController.itemIdAddress==3?MyColors.MainPrimary: MyColors.MainSecondary)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h,),
        Row(
          children: [
            SvgPicture.asset('assets/location2.svg',width: 2.h,height: 2.h,),
            SizedBox(width: 2.w,),
            SizedBox(
                width: 30.h,
                child:Obx(() =>registerController.address2.value!=""? Text(
                  registerController.address2.value.toString(),
                  style:  TextStyle(fontSize: 8.sp,
                      fontFamily: 'alexandria_regular',
                      fontWeight: FontWeight.w300,
                      color:MyColors.MainTrunks),maxLines: 2,)
                    :Text('add_delivery_location'.tr(),
                  style:TextStyle(fontSize: 8.sp,
                      fontFamily: 'alexandria_regular',
                      fontWeight: FontWeight.w300,
                      color:MyColors.MainTrunks),maxLines: 2,),
                )),

          ],
        ),
      ],
    );
  }

  Widget receivingDate(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("receiving_date".tr(),
            style:  TextStyle(fontSize: 11.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color:MyColors.MainBulma)),
        SizedBox(height: 1.h,),
        GestureDetector(
          onTap: (){
            showModalBottomSheet<void>(
                isScrollControlled: true,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                context: context,
                backgroundColor: Colors.white,
                builder: (BuildContext context) =>
                    Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery
                                .of(context)
                                .viewInsets
                                .bottom),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            dropDownTimeButtomSheet(
                              from: "subscription",),
                          ],
                        )));
          },
          child: Container(
            padding: EdgeInsetsDirectional.all(1.h),
            margin: EdgeInsetsDirectional.only(bottom: 1.h),
            decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(Radius.circular(15)),
                border: Border.all(
                  color:MyColors.MainGoku, width: 1,),
                color:  Colors.white),
            child: Row(
              children: [
                SvgPicture.asset("assets/calendar.svg"),
                SizedBox(width: 1.h,),
                SizedBox(
                  width: 32.h,
                  child:Obx(() => dropOffController.finalsubscriptionTime.value!=""?
                  Text(dropOffController.finalsubscriptionTime.value,
                      style:  TextStyle(fontSize: 12.sp,
                          fontFamily: 'alexandria_regular',
                          fontWeight: FontWeight.w300,
                          color:MyColors.MainTrunks))
                      : Text('select_date'.tr(),
                      style:  TextStyle(fontSize: 12.sp,
                          fontFamily: 'alexandria_regular',
                          fontWeight: FontWeight.w300,
                          color:MyColors.MainTrunks))),
                ),
                const Spacer(),
                Transform.rotate(
                    angle:homeController.lang=="en"? 180 *math.pi /180:0,
                    child: SvgPicture.asset('assets/alt_arrow.svg',))
              ],
            ),
          ),
        ),
        Container(
          padding: EdgeInsetsDirectional.all(1.5.h),
          decoration: BoxDecoration(
              borderRadius: const BorderRadius.all(Radius.circular(15)),
              border: Border.all(
                color: MyColors.MainGoku, width: 1.0,),
              color:  MyColors.MainGoku),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SvgPicture.asset("assets/truck.svg"),
                      SizedBox(width: 1.h,),
                      Text("express_access_service".tr(),
                          style:  TextStyle(fontSize: 12.sp,
                              fontFamily: 'alexandria_medium',
                              fontWeight: FontWeight.w300,
                              color:MyColors.MainBulma)),
                      SizedBox(width: 1.h,),
                      Container(
                        padding: EdgeInsetsDirectional.all(0.5.h),
                        decoration: BoxDecoration(
                            borderRadius: const BorderRadius.all(Radius.circular(15)),
                            border: Border.all(
                              color: MyColors.MainBeerus, width: 1.0,),
                            color:  MyColors.MainBeerus),
                        child: Text("6.00 SAR",
                            style:  TextStyle(fontSize: 6.sp,
                                fontFamily: 'alexandria_regular',
                                fontWeight: FontWeight.w400,
                                color:MyColors.MainTrunks)),
                      )
                    ],
                  ),
                  SizedBox(height: 1.h,),
                  SizedBox(
                    width: 30.h,
                    child: Text("representative".tr(),
                        style:  TextStyle(fontSize: 8.sp,
                            fontFamily: 'alexandria_regular',
                            fontWeight: FontWeight.w300,
                            color:MyColors.MainTrunks)),
                  ),
                ],
              ),

              CupertinoSwitch(
                  value: ghassalSubscriptionController.lights,activeColor: MyColors.MainPrimary,
                  onChanged: (bool value){
                    setState(() {
                      ghassalSubscriptionController.lights=value;
                    });
                  })
            ],
          ),
        )
      ],
    );
  }

  Widget coupon(){
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("discount_code".tr(),
              style:  TextStyle(fontSize: 11.sp,
                  fontFamily: 'alexandria_bold',
                  fontWeight: FontWeight.w500,
                  color:MyColors.MainBulma)),
          SizedBox(height: 1.h,),
          Row(
            children: [
              Expanded(
                flex: 1,
                child: SizedBox(
                  height: 7.h,
                  child: TextButton(
                    style: flatButtonStyle,
                    onPressed: () {
                      if(_formKey.currentState!.validate()){

                      }
                    },
                    child: Text('use'.tr(),
                      style:  TextStyle(fontSize: 12.sp,
                          fontFamily: 'alexandria_extraBold',
                          fontWeight: FontWeight.w400,
                          color: Colors.white),),
                  ),
                ),
              ),
              SizedBox(width: 1.h,),
              Expanded(
                flex: 2,
                child: Container(
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(15)),
                      border: Border.all(
                        color: MyColors.MainGoku,
                        width: 1.0,
                      ),
                      color: MyColors.MainGoku),
                  child: TextFormField(
                    autovalidateMode:AutovalidateMode.onUserInteraction ,
                    controller: ghassalSubscriptionController.codeController,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'please_enter_code'.tr();
                      }
                      return null;
                    },
                    maxLines: 1,
                    decoration: const InputDecoration(
                      errorBorder:  OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                        borderSide: BorderSide(color: Colors.red,style: BorderStyle.solid),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                        borderSide: BorderSide(color: MyColors.MainBeerus,style: BorderStyle.solid),
                      ),fillColor: Colors.green,focusColor: Colors.green,
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                          borderSide: BorderSide(style: BorderStyle.solid,color: MyColors.MainBeerus,)
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                        borderSide: BorderSide(color: Colors.red,style: BorderStyle.solid),
                      ) ,
                    ),
                    style:  TextStyle(fontSize: 11.sp,
                        fontFamily: 'alexandria_regular',
                        fontWeight: FontWeight.w300,
                        color: MyColors.MainTrunks),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget payment(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("payment_methods".tr(),
            style:  TextStyle(fontSize: 11.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color:MyColors.MainBulma)),
        SizedBox(height: 1.h,),
        GestureDetector(
          onTap: (){

          },
          child: Container(
            padding: EdgeInsetsDirectional.all(1.h),
            margin: EdgeInsetsDirectional.only(bottom: 1.h),
            decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(Radius.circular(15)),
                border: Border.all(
                  color: MyColors.MainGoku, width: 1,),
                color:  Colors.white),
            child: Row(
              children: [
                SvgPicture.asset("assets/mastercard.svg"),
                SizedBox(width: 1.h,),
                Text("•••• •••• •••• •••• 4679",
                    style:  TextStyle(fontSize: 12.sp,
                        fontFamily: 'alexandria_regular',
                        fontWeight: FontWeight.w400,
                        color:MyColors.MainTrunks)),
                const Spacer(),
                Text("change".tr(),
                    style:  TextStyle(fontSize: 10.sp,
                        fontFamily: 'alexandria_medium',
                        fontWeight: FontWeight.w500,
                        color:MyColors.MainSecondary)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget preferencesList() {
    //if (homeController.brandsList.isNotEmpty) {
    return ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        physics: const ScrollPhysics(),
        itemCount: checkedList.length,//homeController.brandsList.length,
        itemBuilder: (context, int index) {
          return Container(
            padding: EdgeInsetsDirectional.all(1.5.h),
            margin: EdgeInsetsDirectional.only(bottom: 1.h),
            decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(Radius.circular(15)),
                border: Border.all(
                    color: MyColors.MainGoku,
                    width: 2.0),
                color:  Colors.white),
            child: Row(
              children: [
                SvgPicture.asset('assets/leaf.svg'),
                SizedBox(width: 1.h,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("غسيل عضوي",
                        style:  TextStyle(fontSize: 12.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w300,
                            color:MyColors.MainBulma)),
                    SizedBox(height: 1.h,),
                    Text("غير مثير للحساسية وبدون روائح",
                        style:  TextStyle(fontSize: 8.sp,
                            fontFamily: 'alexandria_regular',
                            fontWeight: FontWeight.w300,
                            color:MyColors.MainTrunks)),
                  ],
                ),
                const Spacer(),
                Checkbox(
                  checkColor: Colors.white,
                  value: checkedList[index],
                  activeColor: MyColors.MainPrimary,
                  onChanged: (bool? isChecked) {
                    setState(() {
                      checkedList[index] = isChecked!;
                    });
                  },
                ),
              ],
            ),
          );
        }
    );
    // } else {
    //   return Container();
    // }
  }

  Widget notes(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("notes".tr(),
            style:  TextStyle(fontSize: 11.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color:MyColors.MainBulma)),
        SizedBox(height: 1.h,),
        Container(
          height: 15.h,
          decoration: BoxDecoration(
              borderRadius: const BorderRadius.all(Radius.circular(15)),
              border: Border.all(
                color: MyColors.MainGoku,
                width: 1.0,
              ),
              color:Colors.white),
          child: TextFormField(
            maxLines: 4,
            autovalidateMode:AutovalidateMode.onUserInteraction ,
            controller: ghassalSubscriptionController.noteController,
            decoration:   InputDecoration(
              errorBorder:  const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(15)),
                borderSide: BorderSide(color: Colors.red,style: BorderStyle.solid),
              ),
              enabledBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(15)),
                borderSide: BorderSide(color: MyColors.MainGoku,style: BorderStyle.solid),
              ),
              focusedBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(15)),
                  borderSide: BorderSide(style: BorderStyle.solid,color: MyColors.MainGoku,)
              ),
              focusedErrorBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(15)),
                borderSide: BorderSide(color: Colors.red,style: BorderStyle.solid),
              ) ,
              hintText: 'write'.tr(),
              hintStyle: TextStyle(fontSize: 12.sp,
                  fontFamily: 'lexend_regular',
                  fontWeight: FontWeight.w400,
                  color: MyColors.MainTrunks),
            ),
            style:  TextStyle(fontSize: 12.sp,
                fontFamily: 'alexandria_regular',
                fontWeight: FontWeight.w400,
                color: MyColors.MainZeno),
          ),
        )
      ],
    );
  }

  clearData(){
    dropOffController.subscriptionHours="";
    dropOffController.subscriptionDate="";
    dropOffController.finalsubscriptionTime.value="";
    ghassalSubscriptionController.codeController.clear();
    ghassalSubscriptionController.noteController.clear();
    ghassalSubscriptionController.isSelectedAddress=false;
    ghassalSubscriptionController.addressType="";
    ghassalSubscriptionController.itemIdAddress=-1;
    ghassalSubscriptionController.isSelected=false;
    ghassalSubscriptionController.itemId=-1;
    registerController.address2.value="";
  }

  onAlertButtonsPressed(context) {
    Alert(
      context: context,
      image: SvgPicture.asset('assets/success2.svg',),
      title: 'you_successfully_subscribed'.tr(),
      style:  AlertStyle(
          titleStyle:TextStyle(fontSize: 12.sp,
              fontFamily: 'alexandria_bold',
              fontWeight: FontWeight.w500,
              color: MyColors.MainBulma),
          descStyle: TextStyle(fontSize: 10.sp,
              fontFamily: 'alexandria_regular',
              fontWeight: FontWeight.w300,
              color: MyColors.MainTrunks)
      ),
      desc: 'the_order_was_made_successfully2'.tr(),
      buttons: [
        DialogButton(
          radius: BorderRadius.circular(15),
          height: 7.h,
          onPressed: ()  {
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) {
                  return DrowerPage(index: 0,);
                }));
          },
          color: MyColors.MainPrimary,
          child: Text('home'.tr(),
              style:  TextStyle(
                  fontSize: 12.sp,
                  fontFamily: 'regular',
                  fontWeight: FontWeight.w500,
                  color: Colors.white)),
        ),
      ],
    ).show();
  }

}