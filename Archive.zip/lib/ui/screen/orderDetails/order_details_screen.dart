import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'dart:math' as math;
import 'package:localize_and_translate/localize_and_translate.dart';
import 'package:sizer/sizer.dart';
import 'package:timelines/timelines.dart';
import '../../../business/homeController/HomeController.dart';
import '../../../conustant/my_colors.dart';
import '../buttomSheets/rateOrderSheet/rate_order_buttom_sheet.dart';

class OrderDetailsScreen extends StatefulWidget{
  var code;

  OrderDetailsScreen({required this.code});

  @override
  State<StatefulWidget> createState() {
    return _OrderDetailsScreen();
  }
}

class _OrderDetailsScreen extends State<OrderDetailsScreen>{
  final homeController = Get.put(HomeController());
  var _processes = [];

  var completeColor = Color(0xff5F489D);
  var inProgressColor = Color(0xff867ca1);
  var todoColor = Color(0xffd1d2d7);
  int _processIndex = 2;

  @override
  void initState() {
    super.initState();
    _processes = [
      'ordered'.tr(),
      'receipt'.tr(),
      'the_laundry'.tr(),
      'delivered'.tr(),
      'finish'.tr(),
    ];
  }

  Color getColor(int index) {
    if (index == _processIndex) {
      return inProgressColor;
    } else if (index < _processIndex) {
      return completeColor;
    } else {
      return todoColor;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Transform.rotate(
                angle:homeController.lang=="en"? 180 *math.pi /180:0,
                child: SvgPicture.asset('assets/back.svg',))),
        title: Text(widget.code,
            style:  TextStyle(
                fontSize: 12.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color: MyColors.MainBulma)),
        actions: [
          PopupMenuButton(
            initialValue: 2,color: Colors.white,
            child: Padding(
              padding: EdgeInsets.only(left: 2.h,right: 2.h),
              child: SvgPicture.asset('assets/menu.svg'),
            ),
            itemBuilder: (context) {
              return List.generate(1, (index) {
                return PopupMenuItem(
                  value: index,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SvgPicture.asset('assets/remove.svg'),
                      Text(
                        'cancel_order'.tr(),
                        style: TextStyle(
                            fontSize: 10.sp,
                            fontFamily: 'regular',
                            fontWeight: FontWeight.w500,
                            color: Colors.red),
                      )
                    ],
                  ),
                  onTap: (){
                    showModalBottomSheet<void>(
                        isScrollControlled: true,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                        ),
                        context: context,
                        backgroundColor: Colors.white,
                        builder: (BuildContext context) => Padding(
                            padding: EdgeInsets.only(
                                bottom: MediaQuery.of(context).viewInsets.bottom),
                            child: RateOrderButtomSheet()));
                  },
                );
              });
            },
          ),
        ],
      ),
      body: SizedBox(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        //margin:  EdgeInsetsDirectional.only(end: 1.5.h,start: 1.5.h,bottom: 1.5.h),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              orderStatus(),
              SizedBox(height: 2.5.h,),
              Container(
                margin:  EdgeInsetsDirectional.only(end: 1.5.h,start: 1.5.h,),
                padding: EdgeInsetsDirectional.all(2.h),
                decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(15)),
                    border: Border.all(
                      color: MyColors.MainGoku, width: 1.0,),
                    color:  MyColors.MainGoku),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('address'.tr(),
                        style:  TextStyle(
                            fontSize: 10.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w500,
                            color: MyColors.MainBulma)),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SvgPicture.asset('assets/order_map.svg'),
                        SizedBox(width: 1.h,),
                        Text("18 شارع لقمان,خميس مشيط",
                            style:  TextStyle(
                                fontSize: 10.sp,
                                fontFamily: 'alexandria_regular',
                                fontWeight: FontWeight.w300,
                                color: MyColors.Dark4)),
                      ],
                    )
                  ],
                ),
              ),
              SizedBox(height: 1.h,),
              Container(
                margin:  EdgeInsetsDirectional.only(end: 1.5.h,start: 1.5.h,),
                padding: EdgeInsetsDirectional.all(2.h),
                decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(15)),
                    border: Border.all(
                      color: MyColors.MainGoku, width: 1.0,),
                    color:  MyColors.MainGoku),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('payment_details'.tr(),
                        style:  TextStyle(
                            fontSize: 10.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w500,
                            color: MyColors.MainBulma)),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SvgPicture.asset('assets/mastercard.svg'),
                        SizedBox(width: 1.h,),
                        Text("•••• •••• •••• •••• 4679",
                            style:  TextStyle(
                                fontSize: 10.sp,
                                fontFamily: 'alexandria_regular',
                                fontWeight: FontWeight.w400,
                                color: MyColors.Dark4)),
                      ],
                    )
                  ],
                ),
              ),
              SizedBox(height: 1.h,),
              Container(
                margin:  EdgeInsetsDirectional.only(end: 1.5.h,start: 1.5.h,),
                padding: EdgeInsetsDirectional.all(2.h),
                decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(15)),
                    border: Border.all(
                      color: MyColors.MainGoku, width: 1.0,),
                    color:  MyColors.MainGoku),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text('discount_code'.tr(),
                        style:  TextStyle(
                            fontSize: 10.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w500,
                            color: MyColors.MainBulma)),
                    const Spacer(),
                    Text("12312A8#",
                        style:  TextStyle(
                            fontSize: 12.sp,
                            fontFamily: 'alexandria_regular',
                            fontWeight: FontWeight.w300,
                            color: MyColors.MainBulma)),
                  ],
                ),
              ),
              SizedBox(height: 1.h,),
              Container(
                margin:  EdgeInsetsDirectional.only(end: 1.5.h,start: 1.5.h,),
                padding: EdgeInsetsDirectional.all(2.h),
                decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(15)),
                    border: Border.all(
                      color: MyColors.MainGoku, width: 1.0,),
                    color:  MyColors.MainGoku),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('date'.tr(),
                        style:  TextStyle(
                            fontSize: 10.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w500,
                            color: MyColors.MainBulma)),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("received_date".tr(),
                                style:  TextStyle(
                                    fontSize: 10.sp,
                                    fontFamily: 'alexandria_regular',
                                    fontWeight: FontWeight.w300,
                                    color: MyColors.textColor)),
                            SizedBox(height: 1.h,),
                            Text("الخميس 22-6-2024",
                                style:  TextStyle(
                                    fontSize: 10.sp,
                                    fontFamily: 'alexandria_regular',
                                    fontWeight: FontWeight.w300,
                                    color: MyColors.Dark4)),
                          ],
                        ),
                        SizedBox(width: 5.h,),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("delivery_date".tr(),
                                style:  TextStyle(
                                    fontSize: 10.sp,
                                    fontFamily: 'alexandria_regular',
                                    fontWeight: FontWeight.w300,
                                    color: MyColors.textColor)),
                            SizedBox(height: 1.h,),
                            Text("الخميس 22-6-2024",
                                style:  TextStyle(
                                    fontSize: 10.sp,
                                    fontFamily: 'alexandria_regular',
                                    fontWeight: FontWeight.w300,
                                    color: MyColors.Dark4)),
                          ],
                        ),
                      ],
                    )
                  ],
                ),
              ),
              SizedBox(height: 1.h,),
              Container(
                margin:  EdgeInsetsDirectional.only(end: 1.5.h,start: 1.5.h,),
                padding: EdgeInsetsDirectional.all(2.h),
                decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(15)),
                    border: Border.all(
                      color: MyColors.MainGoku, width: 1.0,),
                    color:  MyColors.MainGoku),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('order_details'.tr(),
                        style:  TextStyle(
                            fontSize: 10.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w500,
                            color: MyColors.MainBulma)),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text("${"service_type".tr()} (washer baskets)",
                            style:  TextStyle(
                                fontSize: 10.sp,
                                fontFamily: 'alexandria_regular',
                                fontWeight: FontWeight.w400,
                                color: MyColors.Dark4)),
                        const Spacer(),
                        Text("60.00 ريال",
                            style:  TextStyle(
                                fontSize: 8.sp,
                                fontFamily: 'alexandria_medium',
                                fontWeight: FontWeight.w400,
                                color: MyColors.MainBulma)),
                      ],
                    ),
                    SizedBox(height: 1.h,),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text("${"basket_size".tr()} (large)",
                            style:  TextStyle(
                                fontSize: 10.sp,
                                fontFamily: 'alexandria_regular',
                                fontWeight: FontWeight.w400,
                                color: MyColors.Dark4)),
                        const Spacer(),
                        Text("60.00 ريال",
                            style:  TextStyle(
                                fontSize: 8.sp,
                                fontFamily: 'alexandria_medium',
                                fontWeight: FontWeight.w400,
                                color: MyColors.MainBulma)),
                      ],
                    ),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text("${"number_baskets".tr()} (3)",
                            style:  TextStyle(
                                fontSize: 10.sp,
                                fontFamily: 'alexandria_regular',
                                fontWeight: FontWeight.w400,
                                color: MyColors.Dark4)),
                        const Spacer(),
                        Text("30.00 ريال +",
                            style:  TextStyle(
                                fontSize: 8.sp,
                                fontFamily: 'alexandria_medium',
                                fontWeight: FontWeight.w400,
                                color: MyColors.MainBulma)),
                      ],
                    ),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text("${"quick_access".tr()} (Activated)",
                            style:  TextStyle(
                                fontSize: 10.sp,
                                fontFamily: 'alexandria_regular',
                                fontWeight: FontWeight.w400,
                                color: MyColors.Dark4)),
                        const Spacer(),
                        Text("30.00 ريال +",
                            style:  TextStyle(
                                fontSize: 8.sp,
                                fontFamily: 'alexandria_medium',
                                fontWeight: FontWeight.w400,
                                color: MyColors.MainBulma)),
                      ],
                    ),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text("غسيل وكوي",
                            style:  TextStyle(
                                fontSize: 10.sp,
                                fontFamily: 'alexandria_regular',
                                fontWeight: FontWeight.w400,
                                color: MyColors.Dark4)),
                        const Spacer(),
                        Text("30.00 ريال +",
                            style:  TextStyle(
                                fontSize: 8.sp,
                                fontFamily: 'alexandria_medium',
                                fontWeight: FontWeight.w400,
                                color: MyColors.MainBulma)),
                      ],
                    ),
                    SizedBox(height: 2.h,),
                    SvgPicture.asset('assets/line4.svg'),
                    SizedBox(height: 2.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text("total".tr(),
                            style:  TextStyle(
                                fontSize: 10.sp,
                                fontFamily: 'alexandria_regular',
                                fontWeight: FontWeight.w400,
                                color: MyColors.Dark4)),
                        const Spacer(),
                        Text("130.00 ريال",
                            style:  TextStyle(
                                fontSize: 8.sp,
                                fontFamily: 'alexandria_medium',
                                fontWeight: FontWeight.w400,
                                color: MyColors.MainBulma)),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 1.h,),
              Container(
                margin:  EdgeInsetsDirectional.only(end: 1.5.h,start: 1.5.h,),
                padding: EdgeInsetsDirectional.all(2.h),
                decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(15)),
                    border: Border.all(
                      color: MyColors.MainGoku, width: 1.0,),
                    color:  MyColors.MainGoku),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('your_note'.tr(),
                        style:  TextStyle(
                            fontSize: 10.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w500,
                            color: MyColors.MainBulma)),
                    SizedBox(height: 1.h,),
                    Text("ذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى",
                        style:  TextStyle(
                            fontSize: 10.sp,
                            fontFamily: 'alexandria_regular',
                            fontWeight: FontWeight.w300,
                            color: MyColors.MainTrunks)),
                  ],
                ),
              ),
              SizedBox(height: 2.h,),
            ],
          ),
        ),
      ),
    );
  }

  Widget orderStatus(){
    return SizedBox(
      height: 12.h,
      child: Timeline.tileBuilder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        theme: TimelineThemeData(
          direction: Axis.horizontal,
          connectorTheme: ConnectorThemeData(
            space:2.h,
            thickness: 3.0,
          ),
        ),
        builder: TimelineTileBuilder.connected(
          connectionDirection: ConnectionDirection.before,
          itemExtentBuilder: (_, __) =>
          MediaQuery.of(context).size.width / _processes.length,
          contentsBuilder: (context, index) {
            return Padding(
              padding:  EdgeInsets.only(top: 1.h),
              child: Text(
                _processes[index],
                style: TextStyle(
                    fontSize: 10.sp,
                    fontFamily: 'alexandria_regular',
                    fontWeight: FontWeight.w400,
                    color: getColor(index)
                ),
              ),
            );
          },
          indicatorBuilder: (_, index) {
            var color;
            var child;
            if (index >= _processIndex) {
              color = inProgressColor;
              child = Padding(
                padding:  EdgeInsets.all(1.2.h),
                child: Text("0${index+1}",
                    style: TextStyle(
                        fontSize: 11.sp,
                        fontFamily: 'alexandria_medium',
                        fontWeight: FontWeight.w500,
                        color: todoColor))
              );
            } else if (index < _processIndex) {
              color = completeColor;
              child = Icon(
                Icons.check,
                color: Colors.white,
                size: 3.h,
              );
            } else {
              color = todoColor;
            }

            if (index <= _processIndex) {
              return Row(
                children: [
                  SizedBox(width: 0.2.h,),
                  DotIndicator(
                    size: 5.h,
                    color: color,
                    child: child,
                  ),
                  SizedBox(width: 0.2.h,),
                ],
              );
            } else {
              return Row(
                children: [
                  SizedBox(width: 0.2.h,),
                  DotIndicator(
                    size: 5.h,
                    color: color,
                    child: child,
                  ),
                  SizedBox(width: 0.2.h,),
                ],
              );
            }
          },
          connectorBuilder: (_, index, type) {
            if (index > 0) {
              if (index == _processIndex) {
                final prevColor = getColor(index - 1);
                final color = getColor(index);
                List<Color> gradientColors;
                if (type == ConnectorType.start) {
                  gradientColors = [Color.lerp(prevColor, color, 0.5)!, color];
                } else {
                  gradientColors = [
                    prevColor,
                    Color.lerp(prevColor, color, 0.5)!
                  ];
                }
                return DecoratedLineConnector(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: gradientColors,
                    ),
                  ),
                );
              } else {
                return SolidLineConnector(
                  color: getColor(index),
                );
              }
            } else {
              return null;
            }
          },
          itemCount: _processes.length,
        ),
      ),
    );
  }

}