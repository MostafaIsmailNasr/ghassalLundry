import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer.dart';

import '../../../../conustant/my_colors.dart';
import 'package:localize_and_translate/localize_and_translate.dart';

import '../../../widget/upOnRequest/clothesCategoryList/ClothesCategoryItem.dart';
import '../../../widget/upOnRequest/productList/ProductItem.dart';

class ClothesButtomSheets extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _ClothesButtomSheets();
  }
}

class _ClothesButtomSheets extends State<ClothesButtomSheets>{
  final ButtonStyle flatButtonStyle = TextButton.styleFrom(
      backgroundColor: MyColors.MainPrimary,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(15)),
      ));
  TextEditingController searchTxtController = TextEditingController();
  var selectedFlage=0;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 1.h,left: 1.h,top: 1.h,bottom: 2.h),
      child: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 2.h,),
              search(),
              SizedBox(height: 2.h,),
              Text("ironing_baskets".tr(),
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_bold',
                      fontWeight: FontWeight.w500,
                      color:MyColors.MainZeno)),
              SizedBox(height: 1.h,),
              categoriesList(),
              SizedBox(height: 1.h,),
              productList(),
              SizedBox(height: 1.h,),
              Container(
                margin: EdgeInsetsDirectional.only(start: 1.h, end: 1.h,),
                width: double.infinity,
                height: 7.h,
                child: TextButton(
                  style: flatButtonStyle,
                  onPressed: () async {

                  },
                  child: Text(
                    'confirm'.tr(),
                    style: TextStyle(
                        fontSize: 12.sp,
                        fontFamily: 'regular',
                        fontWeight: FontWeight.w500,
                        color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget search() {
    return TextFormField(
      textInputAction: TextInputAction.search,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      controller: searchTxtController,
      maxLines: 1,
      decoration: InputDecoration(
        prefixIcon: Padding(
          padding: EdgeInsetsDirectional.fromSTEB(1.2.h, 0, 1.2.h, 0),
          child: SvgPicture.asset('assets/search_normal.svg'),
        ),
        enabledBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(50)),
          borderSide: BorderSide(color: MyColors.MainBeerus, style: BorderStyle.solid),
        ),
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(50)),
          borderSide: BorderSide(style: BorderStyle.solid, color: MyColors.MainBeerus),
        ),
        hintText: 'search_for_product_names'.tr(),
        hintStyle: TextStyle(
          fontSize: 12.sp,
          fontFamily: 'alexandria_regular',
          fontWeight: FontWeight.w300,
          color: MyColors.textColor,
        ),
      ),
      style: TextStyle(
        fontSize: 12.sp,
        fontFamily: 'alexandria_medium',
        fontWeight: FontWeight.w300,
        color: MyColors.MainZeno,
      ),
      onTapOutside: (event) {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      onChanged: (value) {
        // setState(() {
        //   isTextTyped = value.isNotEmpty;
        // });
        // if (value.isEmpty) {
        //   // If the text is empty, refocus the TextFormField
        //   FocusScope.of(context).requestFocus(focusNode);
        //   controller.searchList.clear();
        // } else if (value.length >= 3) {
        //   // If the text is not empty, perform the search
        //   controller.search(1, value);
        //   controller.scroll.addListener(controller.scrollListener);
        //   if (isTextTyped) {
        //     FocusManager.instance.primaryFocus?.unfocus();
        //   }
        // }

      },
    );
  }

  Widget categoriesList() {
    //if (homeController.brandsList.isNotEmpty) {
    return SizedBox(
      height: 7.h,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          shrinkWrap: true,
          physics: const ScrollPhysics(),
          itemCount: 3,//homeController.brandsList.length,
          itemBuilder: (context, int index) {
            return ClothesCategoryItem(
              is_selected: selectedFlage==index,
              onTap: () {
                setState(() {
                  selectedFlage=index;
                });
              },
            );
          }
      ),
    );
    // } else {
    //   return Container();
    // }
  }

  Widget productList() {
    //if (homeController.brandsList.isNotEmpty) {
    return SizedBox(height: 35.h,
      child: ListView.builder(
          scrollDirection: Axis.vertical,
          shrinkWrap: true,
          physics: const ScrollPhysics(),
          itemCount: 6,//homeController.brandsList.length,
          itemBuilder: (context, int index) {
            return ProductItem(

            );
          }
      ),
    );
    // } else {
    //   return Container();
    // }
  }

}