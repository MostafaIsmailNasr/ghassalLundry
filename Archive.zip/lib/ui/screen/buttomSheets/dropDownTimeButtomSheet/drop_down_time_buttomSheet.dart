
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:intl/intl.dart';
import 'package:localize_and_translate/localize_and_translate.dart';
import 'package:sizer/sizer.dart';

import '../../../../business/dropOffController/DropOffController.dart';
import '../../../../conustant/my_colors.dart';
import '../../../../conustant/toast_class.dart';
import '../../../widget/DateDropItem.dart';
import '../../../widget/TimeDropItem.dart';


class dropDownTimeButtomSheet extends StatefulWidget{
  var from;

  dropDownTimeButtomSheet({required this.from});

  @override
  State<StatefulWidget> createState() {
    return _dropDownTimeButtomSheet();
  }
}

class _dropDownTimeButtomSheet extends State<dropDownTimeButtomSheet>{
  final ButtonStyle flatButtonStyle = TextButton.styleFrom(
      backgroundColor: MyColors.MainPrimary,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(15)),
      ));
  var selectedFlage=0;
  var selectedFlageTime;
  final dropOffController = Get.put(DropOffController());

  @override
  void initState() {
    //dropOffController.getDropOffDates(widget.type,widget.date,context);
    //dropOffController.dropDate=null;
    //dropOffController.dropDateHours=null;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return //Obx(() =>!dropOffController.isLoading.value?
    Padding(
      padding:  EdgeInsets.only(right: 2.h,left: 2.h,top: 1.h,bottom: 1.h),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomBar(),
            SizedBox(height: 1.h,),
            dateList(),
            SizedBox(height: 1.h,),
        //Obx(() =>!dropOffController.isLoading2.value?
        timeList(),
            //:const Center(child: CircularProgressIndicator(color: MyColors.MainColor),)),
            SizedBox(height: 1.h,),
            SizedBox(
              width: double.infinity,
              height: 7.h,
              child: TextButton(
                style: flatButtonStyle,
                onPressed: () {
                  if(widget.from=="baskets") {
                    if (dropOffController.basketDate != null &&
                        dropOffController.basketHours != null) {
                      dropOffController.finalBasketTime.value =
                          dropOffController.basketDate + " " +
                              dropOffController.basketHours;
                      Navigator.pop(context);
                    } else {
                      ToastClass.showCustomToast(
                          context, 'please_select_date_and_time_first'.tr(),
                          "error");
                    }
                  }else if(widget.from=="subscription"){
                    if (dropOffController.subscriptionDate != null &&
                        dropOffController.subscriptionHours != null) {
                      dropOffController.finalsubscriptionTime.value =
                          dropOffController.subscriptionDate + " " +
                              dropOffController.subscriptionHours;
                      Navigator.pop(context);
                    } else {
                      ToastClass.showCustomToast(
                          context, 'please_select_date_and_time_first'.tr(),
                          "error");
                    }
                  }else if(widget.from=="upOnRequest"){
                    if (dropOffController.upOnRequestDate != null &&
                        dropOffController.upOnRequestHours != null) {
                      dropOffController.finalupOnRequestTime.value =
                          dropOffController.upOnRequestDate + " " +
                              dropOffController.upOnRequestHours;
                      Navigator.pop(context);
                    } else {
                      ToastClass.showCustomToast(
                          context, 'please_select_date_and_time_first'.tr(),
                          "error");
                    }
                  }
                  else if (widget.from == "homeBasketSub") {
                          if (dropOffController.homeBasketSubDate != null &&
                              dropOffController.homeBasketSubHours != null) {
                            dropOffController.finalHomeBasketSubTime.value =
                                dropOffController.homeBasketSubDate +
                                    " " +
                                    dropOffController.homeBasketSubHours;
                            Navigator.pop(context);
                          } else {
                            ToastClass.showCustomToast(
                                context,
                                'please_select_date_and_time_first'.tr(),
                                "error");
                          }
                        }
                      },
                child: Text('confirm_time'.tr(),
                  style:  TextStyle(fontSize: 12.sp,
                      fontFamily: 'alexandria_medium',
                      fontWeight: FontWeight.w500,
                      color: Colors.white),),
              ),
            )
          ],
        ),
      ));
    //)
    //:const Center(child: CircularProgressIndicator(color: MyColors.MainColor),));
  }

  Widget CustomBar(){
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 3.h,),
        Text("time_receipt".tr(),
          style:  TextStyle(fontSize: 14.sp,
              fontFamily: 'alexandria_bold',
              fontWeight: FontWeight.w600,
              color:MyColors.MainBulma),),
        SizedBox(height: 1.h,),
        Row(
          children: [
            SvgPicture.asset('assets/info_circle.svg'),
            SizedBox(width: 1.h,),
            SizedBox(
              width: 38.h,
              child: Text("please_specify".tr(),
                style:  TextStyle(fontSize: 8.sp,
                    fontFamily: 'alexandria_regular',
                    fontWeight: FontWeight.w300,
                    color:MyColors.MainTrunks),),
            ),
          ],
        ),
        SizedBox(height: 1.h,),
      ],
    );
  }

  Widget dateList() {
    return Container(
      height: 9.5.h,
      margin: EdgeInsetsDirectional.only(bottom: 1.5.h),
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          shrinkWrap: true,
          itemCount: 5,//dropOffController.dropOffDateList.length,
          itemBuilder: (context,int index){
            return DateDropItem(
              is_selected: selectedFlage==index,
              onTap: () {
                setState(() {
                  selectedFlage=index;
                  selectedFlageTime=null;
                  if(widget.from=="baskets") {
                    dropOffController.basketDate =
                    "الثلاثاء13"; //dropOffController.dropOffDateResponse.value.data![index].date;
                  }else if(widget.from=="subscription"){
                    dropOffController.subscriptionDate =
                    "الثلاثاء13"; //dropOffController.dropOffDateResponse.value.data![index].date;
                  }else if(widget.from=="upOnRequest"){
                    dropOffController.upOnRequestDate =
                    "الثلاثاء13"; //dropOffController.dropOffDateResponse.value.data![index].date;
                  }else if(widget.from=="homeBasketSub"){
                    dropOffController.homeBasketSubDate =
                    "الثلاثاء13"; //dropOffController.dropOffDateResponse.value.data![index].date;
                  }
                  //dropOffController.getPickUpHoursDates(context);
                });
              },
                //dropOffDates: dropOffController.dropOffDateList[index]
            );
          }
      ),
    );
  }

  Widget timeList() {
    //if(dropOffController.hoursResponse.value.data!.isNotEmpty){
      return SizedBox(
          height: 20.h,
          child:
          GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: (6 / 2.5),
                crossAxisSpacing: 5,
                mainAxisSpacing: 5,
              ),
              itemCount: 4,//dropOffController.dropOffHoursList.length,
              itemBuilder: (context, int index) {
                return TimeDropItem(
                    is_selected: selectedFlageTime==index,
                    onTap://dropOffController.hoursResponse.value.data?[index].isAvailable==true?
                        () {
                      setState(() {
                        selectedFlageTime=index;
                        //String inputTime=dropOffController.hoursResponse.value.data![index].time!;
                        //final inputFormat = DateFormat('h:mm a');
                        //final outputFormat = DateFormat('HH:mm');
                        //DateTime dateTime = inputFormat.parse(inputTime);
                        if(widget.from=="baskets") {
                          dropOffController.basketHours =
                          "9:00 الى 12:00"; //outputFormat.format(dateTime);
                        }else if(widget.from=="subscription"){
                          dropOffController.subscriptionHours =
                          "9:00 الى 12:00"; //outputFormat.format(dateTime);
                        }else if(widget.from=="upOnRequest"){
                          dropOffController.upOnRequestHours =
                          "9:00 الى 12:00"; //outputFormat.format(dateTime);
                        }else if(widget.from=="homeBasketSub"){
                          dropOffController.homeBasketSubHours =
                          "9:00 الى 12:00"; //outputFormat.format(dateTime);
                        }
                      });
                    }//:null,
                    //hours: dropOffController.dropOffHoursList[index]
                );
              }));
    // }else{
    //   return Container(
    //       height: 20.h,
    //       child:empty());
    // }

  }

}

/*
class empty extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      // margin: EdgeInsets.only(top: 60),
      child: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SvgPicture.asset('assets/no_times.svg',width: 90,height: 90,),
              //SizedBox(height: 10,),
              Text('there_are_no_times'.tr(),
                style: TextStyle(fontSize: 14.sp,
                    fontFamily: 'lexend_bold',
                    fontWeight: FontWeight.w400,
                    color: MyColors.Dark1),
                textAlign: TextAlign.center,
              ),
              //SizedBox(height: 10,),
              Text('your_times_will_appear_here'.tr(),
                style: TextStyle(fontSize: 12.sp,
                    fontFamily: 'lexend_bold',
                    fontWeight: FontWeight.w400,
                    color: MyColors.Dark2),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

}*/
