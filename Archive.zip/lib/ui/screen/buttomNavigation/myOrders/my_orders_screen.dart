import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:sizer/sizer.dart';

import '../../../../business/homeController/HomeController.dart';
import 'dart:math' as math;
import 'package:localize_and_translate/localize_and_translate.dart';

import '../../../../conustant/my_colors.dart';
import '../../../widget/MyOrdersItem.dart';
import '../../buttomSheets/ordersFilterSheet/orders_filter_buttom_sheet.dart';

class MyOrdersScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _MyOrdersScreen();
  }
}

class _MyOrdersScreen extends State<MyOrdersScreen>{
  final homeController = Get.put(HomeController());
  var isSelected=true;
  var itemId=1;
  final ButtonStyle flatButtonStyle = TextButton.styleFrom(
      backgroundColor: MyColors.MainPrimary,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(15)),
      ));
  final ButtonStyle flatButtonStyle2 = TextButton.styleFrom(
      backgroundColor: MyColors.MainGohan,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(15)),
        side: BorderSide(color: MyColors.MainPrimary), // Add this line for border color
      ));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        title: Text('my_orders'.tr(),
            style:  TextStyle(
                fontSize: 12.sp,
                fontFamily: 'alexandria_bold',
                fontWeight: FontWeight.w500,
                color: MyColors.MainBulma)),
        actions: [
          GestureDetector(
              onTap: () {
                showModalBottomSheet<void>(
                    isScrollControlled: true,
                    shape: const RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(20)),
                    ),
                    context: context,
                    backgroundColor: Colors.white,
                    builder: (BuildContext context) => Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).viewInsets.bottom),
                        child: OrdersFilterButtomSheet()));
              },
            child: Padding(
              padding: EdgeInsets.only(left: 2.h,right: 2.h),
              child: SvgPicture.asset('assets/tuning2.svg'),
            ),
          ),
        ],
      ),
      body:homeController.sharedPreferencesService.getBool("islogin")==true?
      Container(
        margin: EdgeInsetsDirectional.all(1.5.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            status(),
            SizedBox(height: 1.h,),
            Expanded(child: myOrderList()),
          ],
        ),
      )
          : pleaseLogin()
    );
  }

  Widget status(){
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          GestureDetector(
            onTap: (){
              setState(() {
                isSelected=true;
                itemId=1;
              });
            },
            child: Container(
              padding: EdgeInsetsDirectional.only(top: 1.h,bottom: 1.h,start: 2.h,end: 2.h),
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(50)),
                  border: Border.all(
                    color:isSelected==true&&itemId==1?MyColors.MainPrimary: MyColors.MainBeerus,
                    width: 1.0,
                  ),
                  color:isSelected==true&&itemId==1?MyColors.MainPrimary: Colors.white),
              child: Center(
                child: Text("all".tr(),
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_medium',
                      fontWeight: FontWeight.w400,
                      color:isSelected==true&&itemId==1?Colors.white:MyColors.MainBeerus),),
              ),
            ),
          ),
          SizedBox(width: 1.h,),
          GestureDetector(
            onTap: (){
              setState(() {
                isSelected=true;
                itemId=2;
              });
            },
            child: Container(
              padding: EdgeInsetsDirectional.only(top: 1.h,bottom: 1.h,start: 2.h,end: 2.h),
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(50)),
                  border: Border.all(
                    color:isSelected==true&&itemId==2?MyColors.MainPrimary: MyColors.MainBeerus,
                    width: 1.0,
                  ),
                  color:isSelected==true&&itemId==2?MyColors.MainPrimary: Colors.white),
              child: Center(
                child: Text("completed".tr(),
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_medium',
                      fontWeight: FontWeight.w400,
                      color:isSelected==true&&itemId==2?Colors.white:MyColors.MainBeerus),),
              ),
            ),
          ),
          SizedBox(width: 1.h,),
          GestureDetector(
            onTap: (){
              setState(() {
                isSelected=true;
                itemId=3;
              });
            },
            child: Container(
              padding: EdgeInsetsDirectional.only(top: 1.h,bottom: 1.h,start: 2.h,end: 2.h),
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(50)),
                  border: Border.all(
                    color:isSelected==true&&itemId==3?MyColors.MainPrimary: MyColors.MainBeerus,
                    width: 1.0,
                  ),
                  color:isSelected==true&&itemId==3?MyColors.MainPrimary: Colors.white),
              child: Center(
                child: Text("under_receipt".tr(),
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_medium',
                      fontWeight: FontWeight.w400,
                      color:isSelected==true&&itemId==3?Colors.white:MyColors.MainBeerus),),
              ),
            ),
          ),
          SizedBox(width: 1.h,),
          GestureDetector(
            onTap: (){
              setState(() {
                isSelected=true;
                itemId=4;
              });
            },
            child: Container(
              padding: EdgeInsetsDirectional.only(top: 1.h,bottom: 1.h,start: 2.h,end: 2.h),
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(50)),
                  border: Border.all(
                    color:isSelected==true&&itemId==4?MyColors.MainPrimary: MyColors.MainBeerus,
                    width: 1.0,
                  ),
                  color:isSelected==true&&itemId==4?MyColors.MainPrimary: Colors.white),
              child: Center(
                child: Text("canceled".tr(),
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_medium',
                      fontWeight: FontWeight.w400,
                      color:isSelected==true&&itemId==4?Colors.white:MyColors.MainBeerus),),
              ),
            ),
          ),
          SizedBox(width: 1.h,),
          GestureDetector(
            onTap: (){
              setState(() {
                isSelected=true;
                itemId=5;
              });
            },
            child: Container(
              padding: EdgeInsetsDirectional.only(top: 1.h,bottom: 1.h,start: 2.h,end: 2.h),
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(50)),
                  border: Border.all(
                    color:isSelected==true&&itemId==5?MyColors.MainPrimary: MyColors.MainBeerus,
                    width: 1.0,
                  ),
                  color:isSelected==true&&itemId==5?MyColors.MainPrimary: Colors.white),
              child: Center(
                child: Text("under_washing".tr(),
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_medium',
                      fontWeight: FontWeight.w400,
                      color:isSelected==true&&itemId==5?Colors.white:MyColors.MainBeerus),),
              ),
            ),
          ),
          SizedBox(width: 1.h,),
          GestureDetector(
            onTap: (){
              setState(() {
                isSelected=true;
                itemId=6;
              });
            },
            child: Container(
              padding: EdgeInsetsDirectional.only(top: 1.h,bottom: 1.h,start: 2.h,end: 2.h),
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(50)),
                  border: Border.all(
                    color: isSelected==true&&itemId==6?MyColors.MainPrimary:MyColors.MainBeerus,
                    width: 1.0,
                  ),
                  color: isSelected==true&&itemId==6?MyColors.MainPrimary:Colors.white),
              child: Center(
                child: Text("under_delivery".tr(),
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_medium',
                      fontWeight: FontWeight.w400,
                      color:isSelected==true&&itemId==6?Colors.white:MyColors.MainBeerus),),
              ),
            ),
          ),
          SizedBox(width: 1.h,),
        ],
      ),
    );
  }

  Widget myOrderList() {
    //if(addressListController.addressList.isNotEmpty){
    return ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        physics: const ScrollPhysics(),
        itemCount: 15,//addressListController.addressList.length,
        itemBuilder: (context, int index) {
          return MyOrdersItem(
            "sub"
            //address: addressListController.addressList[index],
          );
        }
    );
    // }else{
    //   return empty();
    // }
  }

  Widget pleaseLogin(){
    return Container(
      color: MyColors.MainGoku,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      padding: EdgeInsetsDirectional.only(top: 20.h,start: 1.h,end: 1.h),
      //margin: EdgeInsets.only(left: 1.5.h, right: 1.5.h, top: 1.5.h),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SvgPicture.asset('assets/no_orders.svg'),
            SizedBox(height: 1.h,),
            Text('There_are_no_orders'.tr(),
              style: TextStyle(fontSize: 14.sp,
                  fontFamily: 'alexandria_bold',
                  fontWeight: FontWeight.w600,
                  color: MyColors.MainTrunks),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.h,),
            Text('laundry_requests'.tr(),
              style: TextStyle(fontSize: 10.sp,
                  fontFamily: 'alexandria_regular',
                  fontWeight: FontWeight.w300,
                  color: MyColors.MainTrunks),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.5.h,),
            Container(
              margin: EdgeInsetsDirectional.only(start: 1.h, end: 1.h,),
              width: double.infinity,
              height: 7.h,
              child: TextButton(
                style: flatButtonStyle,
                onPressed: () async {
                  Navigator.pushNamed(context, '/login_screen',arguments: "myOrders");
                },
                child: Text(
                  'login'.tr(),
                  style: TextStyle(
                      fontSize: 12.sp,
                      fontFamily: 'regular',
                      fontWeight: FontWeight.w500,
                      color: Colors.white),
                ),
              ),
            ),
            SizedBox(height: 1.5.h,),
            Container(
              margin: EdgeInsetsDirectional.only(start: 1.h, end: 1.h,),
              width: double.infinity,
              height: 7.h,
              child: TextButton(
                style: flatButtonStyle2,
                onPressed: () async {
                  Navigator.pushNamed(context, '/register_screen',arguments: "myOrder_register");
                },
                child: Text(
                  'signup'.tr(),
                  style: TextStyle(
                      fontSize: 12.sp,
                      fontFamily: 'regular',
                      fontWeight: FontWeight.w500,
                      color:MyColors.MainPrimary),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class empty extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Container(
      color: MyColors.MainGoku,
      height: MediaQuery.of(context).size.height,
      //margin: EdgeInsets.only(top: 15.h),
      padding: EdgeInsetsDirectional.only(top: 20.h),
      child: Center(
        child: Column(
          children: [
            //Image(image: AssetImage('assets/offers_empty.png')),
            SvgPicture.asset('assets/no_orders.svg'),
            SizedBox(height: 1.h,),
            Text('There_are_no_orders'.tr(),
              style: TextStyle(fontSize: 14.sp,
                  fontFamily: 'alexandria_bold',
                  fontWeight: FontWeight.w600,
                  color: MyColors.MainTrunks),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.h,),
            Text('laundry_requests'.tr(),
              style: TextStyle(fontSize: 10.sp,
                  fontFamily: 'alexandria_regular',
                  fontWeight: FontWeight.w300,
                  color: MyColors.MainTrunks),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

}