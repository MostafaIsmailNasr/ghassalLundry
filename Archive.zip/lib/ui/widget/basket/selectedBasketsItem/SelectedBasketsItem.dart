import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:sizer/sizer.dart';

import '../../../../business/homeController/HomeController.dart';
import '../../../../conustant/my_colors.dart';
import 'dart:math' as math;

class SelectedBasketsItem extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _SelectedBasketsItem();
  }
}

class _SelectedBasketsItem extends State<SelectedBasketsItem>{
  final homeController = Get.put(HomeController());
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Navigator.pushNamed(context, "/selected_basket_screens");
      },
      child: Container(
        padding: EdgeInsetsDirectional.all(2.h),
        margin: EdgeInsetsDirectional.only(bottom: 1.h),
        decoration: BoxDecoration(
            borderRadius: const BorderRadius.all(Radius.circular(15)),
            border: Border.all(
              color: MyColors.MainGoku, width: 1.0,),
            color:  MyColors.MainGohan),
        child: Row(
          children: [
            SvgPicture.asset("assets/cart1.svg"),
            SizedBox(width: 1.h,),
            Text("3 سلال كبيرة, غسيل وكوي",
                style:  TextStyle(fontSize: 12.sp,
                    fontFamily: 'alexandria_medium',
                    fontWeight: FontWeight.w300,
                    color:MyColors.MainTrunks)),
            const Spacer(),
            Transform.rotate(
                angle:homeController.lang=="en"? 180 *math.pi /180:0,
                child: SvgPicture.asset('assets/alt_arrow.svg',))
          ],
        ),
      ),
    );
  }

}