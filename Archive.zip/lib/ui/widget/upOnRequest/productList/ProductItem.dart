import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:sizer/sizer.dart';

import '../../../../conustant/my_colors.dart';

class ProductItem extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _ProductItem();
  }
}

class _ProductItem extends State<ProductItem>{
  bool isvisible=false;
  int counter=0;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsetsDirectional.all(1.h),
      margin: EdgeInsetsDirectional.only(bottom: 1.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SvgPicture.asset('assets/jacket.svg'),
          SizedBox(width: 1.h,),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("جاكيت",
                  style:  TextStyle(fontSize: 12.sp,
                      fontFamily: 'alexandria_bold',
                      fontWeight: FontWeight.w500,
                      color:MyColors.MainTrunks)),
              Text("19 ريال",
                  style:  TextStyle(fontSize: 10.sp,
                      fontFamily: 'alexandria_medium',
                      fontWeight: FontWeight.w500,
                      color:MyColors.MainPrimary)),
            ],
          ),
          const Spacer(),
          GestureDetector(
              onTap: (){
                setState(() {
                  isvisible=true;
                  counter++;
                });
              },
              child: SvgPicture.asset('assets/ic_round-plus.svg')),
          SizedBox(width: 1.h,),
          Visibility(
            visible: isvisible,
            child: Row(
              children: [
                Text(counter.toString(),
                    style:  TextStyle(fontSize: 12.sp,
                        fontFamily: 'alexandria_bold',
                        fontWeight: FontWeight.w500,
                        color:MyColors.MainTrunks)),
                SizedBox(width: 1.h,),
                counter==1?
                GestureDetector(
                    onTap: (){
                      setState(() {
                        counter=0;
                        isvisible=false;
                      });
                    },
                    child: SvgPicture.asset('assets/remove.svg'))
                    :GestureDetector(
                    onTap: (){
                      setState(() {
                        if(counter>1) {
                          counter--;
                        }
                      });
                    },
                    child: SvgPicture.asset('assets/ic_round-minus.svg'))
              ],
            ),
          )
        ],
      ),
    );
  }

}