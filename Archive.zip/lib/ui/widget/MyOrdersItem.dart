import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:sizer/sizer.dart';
import 'package:localize_and_translate/localize_and_translate.dart';

import '../../conustant/my_colors.dart';

class MyOrdersItem extends StatefulWidget{
  var status;

  MyOrdersItem(this.status);
  @override
  State<StatefulWidget> createState() {
    return _MyOrdersItem();
  }

}

class _MyOrdersItem extends State<MyOrdersItem>{
  var isvisable=false;
  var isvisable2=true;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Navigator.pushNamed(context, '/order_details_screen',arguments: "#5835");
      },
      child: Container(
        margin:  EdgeInsetsDirectional.only(bottom: 1.h),
        decoration:  BoxDecoration(
            borderRadius: const BorderRadius.all(Radius.circular(15)),
            color: MyColors.MainGoku,
            border: Border.all(color: MyColors.MainGoku)),
        child: Padding(
          padding:  EdgeInsets.all(1.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text("order_no".tr(),
                    style:  TextStyle(fontSize: 12.sp,
                        fontFamily: 'alexandria_medium',
                        fontWeight: FontWeight.w500,
                        color:MyColors.Dark),),
                  SizedBox(width: 1.h,),
                  Text("#5835",
                    style:  TextStyle(fontSize: 12.sp,
                        fontFamily: 'alexandria_medium',
                        fontWeight: FontWeight.w500,
                        color:MyColors.Dark),),
                  const Spacer(),
                  Container(
                    decoration:  BoxDecoration(
                        borderRadius: const BorderRadius.all(Radius.circular(15)),
                        color: MyColors.MainPrimary,
                        border: Border.all(color: MyColors.MainPrimary)),
                    padding: EdgeInsetsDirectional.only(top: 1.h,bottom: 1.h,start: 2.h,end: 2.h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        images(),
                        SizedBox(width: 1.h,),
                        Text("إشتراكات غسّال",
                          style:  TextStyle(fontSize: 10.sp,
                              fontFamily: 'alexandria_regular',
                              fontWeight: FontWeight.w300,
                              color:Colors.white),),
                      ],
                    ),
                  )
                ],
              ),
              SizedBox(height: 1.h,),
              Visibility(visible: isvisable2,child: dots()),
              SizedBox(height: 1.h,),
              GestureDetector(
                onTap: (){
                  setState(() {
                    isvisable=true;
                    isvisable2=false;
                  });
                },
                child: Visibility(
                  visible: isvisable2,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text("view_details".tr(),
                        style:  TextStyle(fontSize: 10.sp,
                            fontFamily: 'alexandria_medium',
                            fontWeight: FontWeight.w400,
                            color:MyColors.MainSecondary),),
                      SizedBox(width: 1.h,),
                      SvgPicture.asset('assets/down.svg'),
                    ],
                  ),
                ),
              ),
              Visibility(
                visible: isvisable,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SvgPicture.asset('assets/order_map.svg'),
                        SizedBox(width: 1.h,),
                        Text("18 شارع لقمان,خميس مشيط",
                          style:  TextStyle(fontSize: 10.sp,
                              fontFamily: 'alexandria_regular',
                              fontWeight: FontWeight.w300,
                              color:MyColors.Dark4),),
                      ],
                    ),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SvgPicture.asset('assets/dollar.svg'),
                        SizedBox(width: 1.h,),
                        Text("${"total_price".tr()} 10ريال",
                          style:  TextStyle(fontSize: 10.sp,
                              fontFamily: 'alexandria_regular',
                              fontWeight: FontWeight.w300,
                              color:MyColors.Dark4),),
                      ],
                    ),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SvgPicture.asset('assets/mastercard2.svg'),
                        SizedBox(width: 1.h,),
                        Text("•••• •••• •••• •••• 4679",
                          style:  TextStyle(fontSize: 10.sp,
                              fontFamily: 'alexandria_regular',
                              fontWeight: FontWeight.w400,
                              color:MyColors.Dark4),),
                      ],
                    ),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("received_date".tr(),
                              style:  TextStyle(fontSize: 10.sp,
                                  fontFamily: 'alexandria_regular',
                                  fontWeight: FontWeight.w300,
                                  color:MyColors.textColor),),
                            SizedBox(height: 1.h,),
                            Text("الخميس 22-6-2024",
                              style:  TextStyle(fontSize: 10.sp,
                                  fontFamily: 'alexandria_regular',
                                  fontWeight: FontWeight.w300,
                                  color:MyColors.Dark4),),
                          ],
                        ),
                        SizedBox(width: 8.h,),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("delivery_date".tr(),
                              style:  TextStyle(fontSize: 10.sp,
                                  fontFamily: 'alexandria_regular',
                                  fontWeight: FontWeight.w300,
                                  color:MyColors.textColor),),
                            SizedBox(height: 1.h,),
                            Text("الخميس 22-6-2024",
                              style:  TextStyle(fontSize: 10.sp,
                                  fontFamily: 'alexandria_regular',
                                  fontWeight: FontWeight.w300,
                                  color:MyColors.Dark4),),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(height: 1.h,),
                    Text("notes".tr(),
                      style:  TextStyle(fontSize: 10.sp,
                          fontFamily: 'alexandria_regular',
                          fontWeight: FontWeight.w300,
                          color:MyColors.textColor),),
                    SizedBox(height: 1.h,),
                    Text("ذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى",
                      style:  TextStyle(fontSize: 10.sp,
                          fontFamily: 'alexandria_regular',
                          fontWeight: FontWeight.w300,
                          color:MyColors.Dark4),),
                    SizedBox(height: 2.h,),
                    Text("order_status".tr(),
                      style:  TextStyle(fontSize: 10.sp,
                          fontFamily: 'alexandria_regular',
                          fontWeight: FontWeight.w300,
                          color:MyColors.textColor),),
                    SizedBox(height: 1.h,),
                    dots(),
                    SizedBox(height: 1.h,),
                    SvgPicture.asset('assets/rectangle.svg'),
                    SizedBox(height: 1.h,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text("${"rating".tr()} 4",
                          style:  TextStyle(fontSize: 12.sp,
                              fontFamily: 'alexandria_regular',
                              fontWeight: FontWeight.w300,
                              color:MyColors.MainTrunks),),
                        SizedBox(width: 1.h,),
                        SvgPicture.asset('assets/star.svg'),
                        const Spacer(),
                        Container(
                          padding: EdgeInsetsDirectional.only(start: 2.h,end: 2.h,top: 1.h,bottom: 1.h),
                          decoration: BoxDecoration(
                              borderRadius: const BorderRadius.all(Radius.circular(15)),
                              color: MyColors.MainPrimary,
                              border: Border.all(color: MyColors.MainPrimary)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SvgPicture.asset('assets/restart.svg'),
                              SizedBox(width: 1.h,),
                              Text("reorder".tr(),
                                style:  TextStyle(fontSize: 8.sp,
                                    fontFamily: 'alexandria_regular',
                                    fontWeight: FontWeight.w300,
                                    color:Colors.white),),
                            ],
                          ),
                        )
                      ],
                    ),
                    SizedBox(height: 1.h,),
                    GestureDetector(
                      onTap: (){
                        setState(() {
                          isvisable=false;
                          isvisable2=true;
                        });
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text("close_details".tr(),
                            style:  TextStyle(fontSize: 10.sp,
                                fontFamily: 'alexandria_medium',
                                fontWeight: FontWeight.w400,
                                color:MyColors.MainSecondary),),
                          SizedBox(width: 1.h,),
                          SvgPicture.asset('assets/up.svg'),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
  
  Widget images(){
    if(widget.status=="sub"){
      return SvgPicture.asset('assets/order_type1.svg');
    }else if(widget.status=="baskets"){
      return SvgPicture.asset('assets/order_type2.svg');
    }else if(widget.status=="upon"){
      return SvgPicture.asset('assets/order_type3.svg');
    }else{
      return SvgPicture.asset('assets/order_type1.svg');
    }
  }

  Widget dots(){
    if(widget.status=="sub"){
      return Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SvgPicture.asset('assets/dots.svg'),
          SizedBox(width: 1.h,),
          Text("مكتمل",
            style:  TextStyle(fontSize: 10.sp,
                fontFamily: 'alexandria_medium',
                fontWeight: FontWeight.w400,
                color:MyColors.MainPrimary),),
        ],
      );
    }else if(widget.status=="baskets"){
      return Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SvgPicture.asset('assets/dots.svg'),
          SizedBox(width: 1.h,),
          Text("مكتمل",
            style:  TextStyle(fontSize: 10.sp,
                fontFamily: 'alexandria_medium',
                fontWeight: FontWeight.w400,
                color:MyColors.MainPrimary),),
        ],
      );
    }else if(widget.status=="upon"){
      return Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SvgPicture.asset('assets/dots.svg'),
          SizedBox(width: 1.h,),
          Text("مكتمل",
            style:  TextStyle(fontSize: 10.sp,
                fontFamily: 'alexandria_medium',
                fontWeight: FontWeight.w400,
                color:MyColors.MainPrimary),),
        ],
      );
    }else{
      return Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SvgPicture.asset('assets/dots.svg'),
          SizedBox(width: 1.h,),
          Text("مكتمل",
            style:  TextStyle(fontSize: 10.sp,
                fontFamily: 'alexandria_medium',
                fontWeight: FontWeight.w400,
                color:MyColors.MainPrimary),),
        ],
      );
    }
  }

}