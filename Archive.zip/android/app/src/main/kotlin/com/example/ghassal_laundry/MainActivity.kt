package com.example.ghassal_laundry

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
